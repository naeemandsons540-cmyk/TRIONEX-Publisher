# .txpub format, version 1

A `.txpub` file is a ZIP archive.

```
manifest.json     required
document.json     required
assets/           reserved (images, Phase 2)
previews/         reserved
metadata/         reserved
```

Only these top-level names are accepted. Any entry with `..`, `.`, an empty path segment, a backslash, a colon,
a leading `/`, a control character, or an unknown top-level directory causes the whole package to be rejected.
Individual entries larger than 64 MiB are rejected.

## manifest.json
```json
{ "format": "txpub", "formatVersion": 1, "appVersion": "0.1.0", "documentSha256": "<hex sha-256 of document.json bytes>" }
```
- `formatVersion` greater than the reader's version → rejected ("created by a newer version").
- Lower versions will be migrated in `loadPackageFromBytes` (none exist yet).
- A checksum mismatch → rejected as corrupted.

## document.json
```json
{
  "name": "Untitled",
  "setup": { "width": 595.27, "height": 841.89, "unit": "mm",
             "marginTop": 36, "marginBottom": 36, "marginLeft": 36, "marginRight": 36,
             "bleed": 0, "columns": 1, "gutter": 12, "facingPages": false },
  "layers": [ { "id": "layer-1", "name": "Layer 1", "visible": true, "locked": false } ],
  "pages":  [ { "id": "<uuid>", "objects": [
      { "id": "<uuid>", "type": "rectangle|ellipse|line", "layer": "layer-1",
        "x": 0, "y": 0, "w": 100, "h": 50,
        "fill": "#aarrggbb", "stroke": "#aarrggbb", "strokeWidth": 1, "locked": false } ] } ]
}
```
All lengths are in **points**; `unit` is only the display unit. Object order in `objects` is z-order (last = top).
For `line`, `(x,y)` is the start and `(w,h)` the vector to the end point.

Validation on load: finite numbers, valid colours, unique ids, objects reference existing layers, at least one
page and one layer, page setup within limits (10–14400 pt, margins fit, 1–12 columns, bleed ≤ 72 pt).

## Saving
The package is built in memory, then written with `QSaveFile` (temporary file + atomic rename), so a failed or
interrupted save never replaces the previous valid file.
