#ifndef AppVersion
  #define AppVersion "0.1.0"
#endif

[Setup]
AppId={{B3B3A1E2-5D1C-4F4B-9C31-7A2E0B6F1C11}
AppName=TRIONEX Publisher
AppVersion={#AppVersion}
AppPublisher=TRIONEX
DefaultDirName={autopf}\TRIONEX Publisher
DefaultGroupName=TRIONEX Publisher
OutputDir=..\dist\installer
OutputBaseFilename=TRIONEXPublisher-Setup
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequiredOverridesAllowed=dialog
UninstallDisplayIcon={app}\TRIONEXPublisher.exe

[Files]
Source: "..\dist\TRIONEXPublisher\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\TRIONEX Publisher"; Filename: "{app}\TRIONEXPublisher.exe"
Name: "{autodesktop}\TRIONEX Publisher"; Filename: "{app}\TRIONEXPublisher.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked

[Registry]
Root: HKA; Subkey: "Software\Classes\.txpub"; ValueType: string; ValueData: "TRIONEX.Publication"; Flags: uninsdeletevalue
Root: HKA; Subkey: "Software\Classes\TRIONEX.Publication"; ValueType: string; ValueData: "TRIONEX Publication"; Flags: uninsdeletekey
Root: HKA; Subkey: "Software\Classes\TRIONEX.Publication\shell\open\command"; ValueType: string; ValueData: """{app}\TRIONEXPublisher.exe"" ""%1"""

[Run]
Filename: "{app}\TRIONEXPublisher.exe"; Description: "Launch TRIONEX Publisher"; Flags: nowait postinstall skipifsilent
