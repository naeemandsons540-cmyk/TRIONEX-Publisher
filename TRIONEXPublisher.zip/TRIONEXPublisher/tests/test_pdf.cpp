#include <QtTest>
#include <QTemporaryDir>
#include "core/Render.h"

using namespace trionex;

class TestPdf : public QObject {
    Q_OBJECT
private slots:
    void exportsPdf() {
        Document d;
        d.setName("PDF test");
        PageSetup s; s.width = 300; s.height = 200;
        d.setSetup(s);
        for (int i = 0; i < 3; ++i) d.insertPage(-1, Page{Document::newId(), {}});
        Object o; o.id = Document::newId(); o.layerId = d.defaultLayerId();
        o.x = 10; o.y = 10; o.w = 100; o.h = 50;
        d.insertObject(0, -1, o);

        QTemporaryDir dir; QVERIFY(dir.isValid());
        const QString path = dir.filePath("out.pdf");
        QString err;
        QVERIFY2(exportPdf(d, path, &err), qPrintable(err));
        QFile f(path);
        QVERIFY(f.open(QIODevice::ReadOnly));
        const QByteArray bytes = f.readAll();
        QVERIFY(bytes.startsWith("%PDF-"));
        QVERIFY(bytes.size() > 500);
        // Page count / MediaBox are verified manually in an independent reader (see README).
    }

    void failsOnBadPath() {
        Document d;
        d.insertPage(-1, Page{Document::newId(), {}});
        QString err;
        QVERIFY(!exportPdf(d, "/nonexistent-dir-xyz/out.pdf", &err));
        QVERIFY(!err.isEmpty());
    }
};

QTEST_MAIN(TestPdf)
#include "test_pdf.moc"
