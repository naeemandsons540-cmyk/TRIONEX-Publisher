#include <QtTest>
#include <cmath>
#include "core/Document.h"

using namespace trionex;

static Object makeObj(const Document& d, ObjectType t = ObjectType::Rectangle) {
    Object o;
    o.id = Document::newId();
    o.type = t;
    o.layerId = d.defaultLayerId();
    o.x = 10; o.y = 20; o.w = 100; o.h = 50;
    return o;
}

class TestDocument : public QObject {
    Q_OBJECT
private slots:
    void unitConversion() {
        QVERIFY(qAbs(unitToPoints(25.4, Unit::Millimetre) - 72.0) < 1e-9);
        QVERIFY(qAbs(unitToPoints(1, Unit::Inch) - 72.0) < 1e-9);
        QVERIFY(qAbs(unitToPoints(2.54, Unit::Centimetre) - 72.0) < 1e-9);
        QVERIFY(qAbs(pointsToUnit(unitToPoints(210, Unit::Millimetre), Unit::Millimetre) - 210) < 1e-9);
        QVERIFY(unitFromName("mm").has_value());
        QVERIFY(!unitFromName("furlong").has_value());
    }

    void setupValidation() {
        PageSetup s;
        QVERIFY(Document::validateSetup(s).isEmpty());
        s.width = 0;
        QVERIFY(!Document::validateSetup(s).isEmpty());
        s = PageSetup(); s.marginLeft = -1;
        QVERIFY(!Document::validateSetup(s).isEmpty());
        s = PageSetup(); s.marginLeft = s.width;
        QVERIFY(!Document::validateSetup(s).isEmpty());
        s = PageSetup(); s.columns = 0;
        QVERIFY(!Document::validateSetup(s).isEmpty());
        s = PageSetup(); s.bleed = 500;
        QVERIFY(!Document::validateSetup(s).isEmpty());
        s = PageSetup(); s.width = std::nan("");
        QVERIFY(!Document::validateSetup(s).isEmpty());
    }

    void jsonRoundTrip() {
        Document d;
        d.setName("Round trip");
        d.insertPage(-1, Page{Document::newId(), {}});
        d.insertPage(-1, Page{Document::newId(), {}});
        d.insertObject(0, -1, makeObj(d));
        d.insertObject(1, -1, makeObj(d, ObjectType::Ellipse));
        d.insertObject(1, -1, makeObj(d, ObjectType::Line));
        const QJsonObject j = d.toJson();
        QString err;
        auto d2 = Document::fromJson(j, &err);
        QVERIFY2(d2, qPrintable(err));
        QCOMPARE(d2->pageCount(), 2);
        QCOMPARE(d2->page(1).objects.size(), 2);
        QVERIFY(d2->toJson() == j);
    }

    void rejectsUnknownLayer() {
        Document d;
        d.insertPage(-1, Page{Document::newId(), {}});
        Object o = makeObj(d);
        o.layerId = "nope";
        d.insertObject(0, -1, o);
        QString err;
        QVERIFY(!Document::fromJson(d.toJson(), &err));
        QVERIFY(!err.isEmpty());
    }

    void rejectsNoPages() {
        Document d;
        QString err;
        QVERIFY(!Document::fromJson(d.toJson(), &err));
    }

    void rejectsDuplicateIds() {
        Document d;
        d.insertPage(-1, Page{Document::newId(), {}});
        Object o = makeObj(d);
        d.insertObject(0, -1, o);
        d.insertObject(0, -1, o);
        QString err;
        QVERIFY(!Document::fromJson(d.toJson(), &err));
    }

    void lockingIsEnforced() {
        Document d;
        d.insertPage(-1, Page{Document::newId(), {}});
        Object o = makeObj(d);
        d.insertObject(0, -1, o);
        QVERIFY(d.canEdit(o.id));
        Layer l = *d.layer(d.defaultLayerId());
        l.locked = true;
        d.setLayer(l);
        QVERIFY(!d.canEdit(o.id));
        l.locked = false;
        d.setLayer(l);
        QVERIFY(d.canEdit(o.id));
        Object locked = o;
        locked.locked = true;
        d.replaceObject(o.id, locked);
        QVERIFY(!d.canEdit(o.id));
        l.visible = false;
        locked.locked = false;
        d.replaceObject(o.id, locked);
        d.setLayer(l);
        QVERIFY(!d.canEdit(o.id));
    }
};

QTEST_MAIN(TestDocument)
#include "test_document.moc"
