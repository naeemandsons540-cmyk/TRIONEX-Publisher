#include <QtTest>
#include <QUndoStack>
#include "core/Commands.h"

using namespace trionex;

static Object makeObj(const Document& d, double x = 10) {
    Object o;
    o.id = Document::newId();
    o.layerId = d.defaultLayerId();
    o.x = x; o.y = 20; o.w = 100; o.h = 50;
    return o;
}

class TestCommands : public QObject {
    Q_OBJECT
private slots:
    void addUndoRedo() {
        Document d; QUndoStack u;
        d.insertPage(-1, Page{Document::newId(), {}});
        const Object o = makeObj(d);
        u.push(new AddObjectCommand(&d, 0, o));
        QCOMPARE(d.page(0).objects.size(), 1);
        u.undo();
        QCOMPARE(d.page(0).objects.size(), 0);
        u.redo();
        QCOMPARE(d.page(0).objects.size(), 1);
        QCOMPARE(d.page(0).objects[0].id, o.id);
    }

    void modifyUndoRedo() {
        Document d; QUndoStack u;
        d.insertPage(-1, Page{Document::newId(), {}});
        const Object o = makeObj(d);
        d.insertObject(0, -1, o);
        Object moved = o; moved.x = 99; moved.w = 7;
        u.push(new ModifyObjectCommand(&d, o, moved, "Move"));
        QCOMPARE(d.object(o.id)->x, 99.0);
        u.undo();
        QCOMPARE(d.object(o.id)->x, 10.0);
        QCOMPARE(d.object(o.id)->w, 100.0);
        u.redo();
        QCOMPARE(d.object(o.id)->w, 7.0);
    }

    void deleteRestoresZOrder() {
        Document d; QUndoStack u;
        d.insertPage(-1, Page{Document::newId(), {}});
        const Object a = makeObj(d, 1), b = makeObj(d, 2), c = makeObj(d, 3);
        d.insertObject(0, -1, a); d.insertObject(0, -1, b); d.insertObject(0, -1, c);
        u.push(new DeleteObjectsCommand(&d, {a.id, c.id}));
        QCOMPARE(d.page(0).objects.size(), 1);
        QCOMPARE(d.page(0).objects[0].id, b.id);
        u.undo();
        QCOMPARE(d.page(0).objects.size(), 3);
        QCOMPARE(d.page(0).objects[0].id, a.id);
        QCOMPARE(d.page(0).objects[1].id, b.id);
        QCOMPARE(d.page(0).objects[2].id, c.id);
        u.redo();
        QCOMPARE(d.page(0).objects.size(), 1);
    }

    void arrange() {
        Document d; QUndoStack u;
        d.insertPage(-1, Page{Document::newId(), {}});
        const Object a = makeObj(d, 1), b = makeObj(d, 2), c = makeObj(d, 3);
        d.insertObject(0, -1, a); d.insertObject(0, -1, b); d.insertObject(0, -1, c);
        u.push(new ArrangeCommand(&d, a.id, true));
        QCOMPARE(d.page(0).objects.last().id, a.id);
        u.undo();
        QCOMPARE(d.page(0).objects.first().id, a.id);
        u.push(new ArrangeCommand(&d, c.id, false));
        QCOMPARE(d.page(0).objects.first().id, c.id);
    }

    void pagesKeepObjects() {
        Document d; QUndoStack u;
        d.insertPage(-1, Page{Document::newId(), {}});
        d.insertPage(-1, Page{Document::newId(), {}});
        const Object o = makeObj(d);
        d.insertObject(1, -1, o);
        u.push(new DeletePageCommand(&d, 1));
        QCOMPARE(d.pageCount(), 1);
        QVERIFY(d.object(o.id) == nullptr);
        u.undo();
        QCOMPARE(d.pageCount(), 2);
        QVERIFY(d.object(o.id) != nullptr);
        u.push(new AddPageCommand(&d, 1, Page{Document::newId(), {}}));
        QCOMPARE(d.pageCount(), 3);
        u.undo();
        QCOMPARE(d.pageCount(), 2);
    }

    void macroUndoesAtomically() {
        Document d; QUndoStack u;
        d.insertPage(-1, Page{Document::newId(), {}});
        const Object a = makeObj(d, 1), b = makeObj(d, 2);
        d.insertObject(0, -1, a); d.insertObject(0, -1, b);
        Object a2 = a, b2 = b; a2.x = 50; b2.x = 60;
        u.beginMacro("Move");
        u.push(new ModifyObjectCommand(&d, a, a2, "m"));
        u.push(new ModifyObjectCommand(&d, b, b2, "m"));
        u.endMacro();
        u.undo();
        QCOMPARE(d.object(a.id)->x, 1.0);
        QCOMPARE(d.object(b.id)->x, 2.0);
    }
};

QTEST_MAIN(TestCommands)
#include "test_commands.moc"
