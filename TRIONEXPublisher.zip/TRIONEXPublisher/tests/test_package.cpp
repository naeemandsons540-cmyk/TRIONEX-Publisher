#include <QtTest>
#include <QTemporaryDir>
#include <QCryptographicHash>
#include <QJsonDocument>
#include <cstring>
#include <miniz.h>
#include "core/Package.h"

using namespace trionex;

static std::unique_ptr<Document> sample() {
    auto d = std::make_unique<Document>();
    d->setName("Sample");
    PageSetup s; s.width = 400; s.height = 300; s.columns = 2; s.bleed = 9;
    d->setSetup(s);
    for (int i = 0; i < 3; ++i) d->insertPage(-1, Page{Document::newId(), {}});
    Object o; o.id = Document::newId(); o.layerId = d->defaultLayerId();
    o.type = ObjectType::Ellipse; o.x = 12.5; o.y = 40; o.w = 80; o.h = 60;
    o.fill = QColor(10, 20, 30, 128);
    d->insertObject(1, -1, o);
    return d;
}

static QByteArray makeZip(const QList<QPair<QString, QByteArray>>& entries) {
    mz_zip_archive z; std::memset(&z, 0, sizeof z);
    mz_zip_writer_init_heap(&z, 0, 0);
    for (const auto& e : entries) {
        const QByteArray name = e.first.toUtf8();
        mz_zip_writer_add_mem(&z, name.constData(), e.second.constData(), size_t(e.second.size()), MZ_DEFAULT_LEVEL);
    }
    void* buf = nullptr; size_t sz = 0;
    mz_zip_writer_finalize_heap_archive(&z, &buf, &sz);
    QByteArray out(static_cast<const char*>(buf), qsizetype(sz));
    mz_free(buf);
    mz_zip_writer_end(&z);
    return out;
}

class TestPackage : public QObject {
    Q_OBJECT
private slots:
    void saveAndReopen() {
        QTemporaryDir dir; QVERIFY(dir.isValid());
        const QString path = dir.filePath("a.txpub");
        auto d = sample();
        QString err;
        QVERIFY2(savePackage(*d, path, &err), qPrintable(err));
        auto r = loadPackage(path, &err);
        QVERIFY2(r, qPrintable(err));
        QVERIFY(r->toJson() == d->toJson());
        QCOMPARE(r->pageCount(), 3);
        QCOMPARE(r->page(1).objects.size(), 1);
        QCOMPARE(r->page(1).objects[0].fill.alpha(), 128);
    }

    void overwriteKeepsFileValid() {
        QTemporaryDir dir;
        const QString path = dir.filePath("b.txpub");
        auto d = sample();
        QString err;
        QVERIFY(savePackage(*d, path, &err));
        d->setName("Second");
        QVERIFY(savePackage(*d, path, &err));
        auto r = loadPackage(path, &err);
        QVERIFY(r);
        QCOMPARE(r->name(), QString("Second"));
        // A failed save (bad directory) must not touch the existing file.
        QVERIFY(!savePackage(*d, dir.filePath("missing/dir/x.txpub"), &err));
        QVERIFY(loadPackage(path, &err));
    }

    void rejectsGarbageAndTruncation() {
        QString err;
        QVERIFY(!loadPackageFromBytes("this is not a zip file", &err));
        QVERIFY(!err.isEmpty());
        auto d = sample();
        QByteArray bytes = buildPackageBytes(*d, &err);
        QVERIFY(!bytes.isEmpty());
        QVERIFY(!loadPackageFromBytes(bytes.left(bytes.size() / 2), &err));
        QVERIFY(!loadPackageFromBytes(QByteArray(), &err));
    }

    void rejectsPathTraversal() {
        auto d = sample();
        QString err;
        const QByteArray good = buildPackageBytes(*d, &err);
        QVERIFY(loadPackageFromBytes(good, &err));
        const QByteArray bad = makeZip({{"manifest.json", "{}"}, {"document.json", "{}"},
                                        {"../evil.txt", "x"}});
        QVERIFY(!loadPackageFromBytes(bad, &err));
        QVERIFY(err.contains("unsafe", Qt::CaseInsensitive));
        QVERIFY(!isSafeEntryName("../x"));
        QVERIFY(!isSafeEntryName("assets/../../x"));
        QVERIFY(!isSafeEntryName("/abs"));
        QVERIFY(!isSafeEntryName("C:/x"));
        QVERIFY(!isSafeEntryName("assets\\x"));
        QVERIFY(!isSafeEntryName("other/file.txt"));
        QVERIFY(isSafeEntryName("assets/img.png"));
        QVERIFY(isSafeEntryName("document.json"));
    }

    void detectsChecksumMismatch() {
        const QByteArray man = R"({"format":"txpub","formatVersion":1,"documentSha256":"deadbeef"})";
        auto d = sample();
        const QByteArray doc = QJsonDocument(d->toJson()).toJson();
        QString err;
        QVERIFY(!loadPackageFromBytes(makeZip({{"manifest.json", man}, {"document.json", doc}}), &err));
        QVERIFY(err.contains("checksum", Qt::CaseInsensitive));
    }

    void rejectsNewerVersion() {
        auto d = sample();
        const QByteArray doc = QJsonDocument(d->toJson()).toJson();
        const QByteArray man = QByteArray(R"({"format":"txpub","formatVersion":999,"documentSha256":")") +
            QCryptographicHash::hash(doc, QCryptographicHash::Sha256).toHex() + "\"}";
        QString err;
        QVERIFY(!loadPackageFromBytes(makeZip({{"manifest.json", man}, {"document.json", doc}}), &err));
        QVERIFY(err.contains("newer", Qt::CaseInsensitive));
    }

    void rejectsMissingEntries() {
        QString err;
        QVERIFY(!loadPackageFromBytes(makeZip({{"manifest.json", "{}"}}), &err));
    }
};

QTEST_MAIN(TestPackage)
#include "test_package.moc"
