#pragma once
#include <QAction>
#include <QLabel>
#include <QListWidget>
#include <QMainWindow>
#include <QMenu>
#include <QTimer>
#include <QUndoStack>
#include <memory>

#include "CanvasView.h"
#include "PropertiesPanel.h"
#include "core/Document.h"

namespace trionex {

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow();
    void openPath(const QString& path);

protected:
    void closeEvent(QCloseEvent* e) override;

private:
    void createActions();
    void setDocument(std::unique_ptr<Document> doc, const QString& path, bool recovered = false);
    bool isModified() const;
    bool maybeSave();
    bool save();
    bool saveAs();
    bool saveTo(const QString& path);
    void newDocument();
    void openDocument();
    void exportPdf();
    void addPage();
    void deletePage();
    void refreshPages();
    void onDocChanged();
    void onSelectionChanged();
    void onPropertyEdited(const Object& after);
    void updateTitle();
    void updateRecentMenu();
    void addRecent(const QString& path);
    QString recoveryDir() const;
    void autosave();
    void clearRecovery();
    void checkRecovery();

    std::unique_ptr<Document> m_doc;
    QUndoStack* m_undo;
    CanvasView* m_canvas;
    QListWidget* m_pageList;
    PropertiesPanel* m_props;
    QMenu* m_recentMenu = nullptr;
    QLabel* m_zoomLabel;
    QLabel* m_pageLabel;
    QList<QAction*> m_toolActions;
    QTimer* m_autosaveTimer;
    QString m_path;
    bool m_recovered = false;
    bool m_docChangePending = false;
};

} // namespace trionex
