#include "MainWindow.h"

#include <QActionGroup>
#include <QCloseEvent>
#include <QDir>
#include <QDockWidget>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QJsonDocument>
#include <QMenuBar>
#include <QMessageBox>
#include <QSaveFile>
#include <QSettings>
#include <QStandardPaths>
#include <QStatusBar>
#include <QToolBar>

#include "NewDocumentDialog.h"
#include "core/Commands.h"
#include "core/Package.h"
#include "core/Render.h"

namespace trionex {

namespace {
template <class F>
QAction* mk(QObject* parent, QMenu* menu, const QString& text, const QKeySequence& ks, F&& fn) {
    auto* a = new QAction(text, parent);
    if (!ks.isEmpty()) a->setShortcut(ks);
    QObject::connect(a, &QAction::triggered, parent, std::forward<F>(fn));
    menu->addAction(a);
    return a;
}

std::unique_ptr<Document> makeBlank(const QString& name, const PageSetup& s, int pages) {
    auto d = std::make_unique<Document>();
    d->setName(name);
    d->setSetup(s);
    for (int i = 0; i < pages; ++i) d->insertPage(-1, Page{Document::newId(), {}});
    return d;
}
} // namespace

MainWindow::MainWindow() {
    resize(1280, 800);
    m_undo = new QUndoStack(this);
    m_canvas = new CanvasView(this);
    setCentralWidget(m_canvas);

    m_pageList = new QListWidget(this);
    auto* pagesDock = new QDockWidget(tr("Pages"), this);
    pagesDock->setWidget(m_pageList);
    addDockWidget(Qt::LeftDockWidgetArea, pagesDock);

    m_props = new PropertiesPanel(this);
    auto* propsDock = new QDockWidget(tr("Properties"), this);
    propsDock->setWidget(m_props);
    addDockWidget(Qt::RightDockWidgetArea, propsDock);

    m_zoomLabel = new QLabel(this);
    m_pageLabel = new QLabel(this);
    statusBar()->addPermanentWidget(m_pageLabel);
    statusBar()->addPermanentWidget(m_zoomLabel);

    createActions();

    connect(m_pageList, &QListWidget::currentRowChanged, this, [this](int row) {
        if (row >= 0 && row != m_canvas->currentPage()) {
            m_canvas->setCurrentPage(row);
            m_pageLabel->setText(tr("Page %1 / %2").arg(row + 1).arg(m_doc ? m_doc->pageCount() : 0));
        }
    });
    connect(m_canvas, &CanvasView::selectionChanged, this, &MainWindow::onSelectionChanged);
    connect(m_canvas, &CanvasView::zoomChanged, this, [this](double z) {
        m_zoomLabel->setText(tr("Zoom %1%").arg(qRound(z * 100)));
    });
    connect(m_canvas, &CanvasView::toolFinished, this, [this] {
        m_toolActions.first()->setChecked(true);
        m_canvas->setTool(Tool::Select);
    });
    connect(m_props, &PropertiesPanel::edited, this, &MainWindow::onPropertyEdited);
    connect(m_undo, &QUndoStack::cleanChanged, this, [this] { updateTitle(); });
    connect(m_undo, &QUndoStack::indexChanged, this, [this] { updateTitle(); });

    m_autosaveTimer = new QTimer(this);
    m_autosaveTimer->setInterval(QSettings().value("autosaveSeconds", 60).toInt() * 1000);
    connect(m_autosaveTimer, &QTimer::timeout, this, &MainWindow::autosave);
    m_autosaveTimer->start();

    PageSetup s;
    setDocument(makeBlank(tr("Untitled"), s, 1), QString());
    QTimer::singleShot(0, this, &MainWindow::checkRecovery);
}

void MainWindow::createActions() {
    // ---- File
    QMenu* file = menuBar()->addMenu(tr("&File"));
    mk(this, file, tr("&New..."), QKeySequence::New, [this] { newDocument(); });
    mk(this, file, tr("&Open..."), QKeySequence::Open, [this] { openDocument(); });
    m_recentMenu = file->addMenu(tr("Open &Recent"));
    file->addSeparator();
    mk(this, file, tr("&Save"), QKeySequence::Save, [this] { save(); });
    mk(this, file, tr("Save &As..."), QKeySequence::SaveAs, [this] { saveAs(); });
    file->addSeparator();
    mk(this, file, tr("&Export PDF..."), QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_E),
       [this] { exportPdf(); });
    file->addSeparator();
    mk(this, file, tr("E&xit"), QKeySequence(Qt::ALT | Qt::Key_F4), [this] { close(); });
    updateRecentMenu();

    // ---- Edit
    QMenu* edit = menuBar()->addMenu(tr("&Edit"));
    QAction* undo = m_undo->createUndoAction(this, tr("&Undo"));
    undo->setShortcut(QKeySequence::Undo);
    QAction* redo = m_undo->createRedoAction(this, tr("&Redo"));
    redo->setShortcut(QKeySequence::Redo);
    edit->addAction(undo);
    edit->addAction(redo);
    edit->addSeparator();
    mk(this, edit, tr("&Delete"), QKeySequence(Qt::Key_Delete), [this] { m_canvas->deleteSelection(); });
    mk(this, edit, tr("Select &All"), QKeySequence::SelectAll, [this] { m_canvas->selectAll(); });

    // ---- Layout
    QMenu* layout = menuBar()->addMenu(tr("&Layout"));
    mk(this, layout, tr("&Add Page"), QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_N),
       [this] { addPage(); });
    mk(this, layout, tr("&Delete Page"), QKeySequence(), [this] { deletePage(); });

    // ---- Object
    QMenu* obj = menuBar()->addMenu(tr("&Object"));
    mk(this, obj, tr("Bring to &Front"), QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_BracketRight),
       [this] { m_canvas->arrangeSelection(true); });
    mk(this, obj, tr("Send to &Back"), QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_BracketLeft),
       [this] { m_canvas->arrangeSelection(false); });
    obj->addSeparator();
    mk(this, obj, tr("&Lock"), QKeySequence(Qt::CTRL | Qt::Key_L),
       [this] { m_canvas->setSelectionLocked(true); });
    mk(this, obj, tr("&Unlock"), QKeySequence(Qt::CTRL | Qt::ALT | Qt::Key_L),
       [this] { m_canvas->setSelectionLocked(false); });

    // ---- View
    QMenu* view = menuBar()->addMenu(tr("&View"));
    mk(this, view, tr("Zoom &In"), QKeySequence::ZoomIn, [this] { m_canvas->zoomBy(1.25); });
    mk(this, view, tr("Zoom &Out"), QKeySequence::ZoomOut, [this] { m_canvas->zoomBy(0.8); });
    mk(this, view, tr("&Fit Page"), QKeySequence(Qt::CTRL | Qt::Key_0), [this] { m_canvas->fitPage(); });

    // ---- Help
    QMenu* help = menuBar()->addMenu(tr("&Help"));
    mk(this, help, tr("&Keyboard Shortcuts"), QKeySequence(), [this] {
        QMessageBox::information(
            this, tr("Keyboard Shortcuts"),
            tr("Ctrl+N New, Ctrl+O Open, Ctrl+S Save, Ctrl+Shift+S Save As\n"
               "Ctrl+Z Undo, Ctrl+Y Redo, Delete removes selection\n"
               "Arrow keys nudge 1 pt (Shift: 10 pt)\n"
               "Ctrl+Wheel zoom, Middle-drag pan, Ctrl+0 fit page\n"
               "Ctrl+L lock, Ctrl+Alt+L unlock"));
    });
    mk(this, help, tr("&About TRIONEX Publisher"), QKeySequence(), [this] {
        QMessageBox::about(
            this, tr("About TRIONEX Publisher"),
            tr("TRIONEX Publisher %1\n\nEarly development build. Implemented: documents, pages, "
               "rectangles/ellipses/lines, selection/move/resize, undo/redo, .txpub save/open, "
               "autosave recovery, basic vector PDF export.\n\nNot yet implemented: text frames, "
               "images, layers panel, styles, parent pages, preflight.")
                .arg(QString::fromLatin1(kAppVersion)));
    });

    // ---- Toolbar (tools)
    QToolBar* tb = addToolBar(tr("Tools"));
    tb->setMovable(false);
    auto* group = new QActionGroup(this);
    const struct {
        const char* name;
        Tool tool;
    } tools[] = {{"Select", Tool::Select},
                 {"Rectangle", Tool::Rectangle},
                 {"Ellipse", Tool::Ellipse},
                 {"Line", Tool::Line}};
    for (const auto& t : tools) {
        auto* a = new QAction(tr(t.name), this);
        a->setCheckable(true);
        group->addAction(a);
        tb->addAction(a);
        m_toolActions << a;
        const Tool tool = t.tool;
        connect(a, &QAction::triggered, this, [this, tool] { m_canvas->setTool(tool); });
    }
    m_toolActions.first()->setChecked(true);
}

bool MainWindow::isModified() const { return !m_undo->isClean() || m_recovered; }

void MainWindow::setDocument(std::unique_ptr<Document> doc, const QString& path, bool recovered) {
    m_canvas->setDocument(nullptr, nullptr);
    m_undo->clear(); // commands hold raw Document pointers: clear before destroying
    m_doc = std::move(doc);
    m_path = path;
    m_recovered = recovered;
    connect(m_doc.get(), &Document::changed, this, &MainWindow::onDocChanged, Qt::QueuedConnection);
    m_canvas->setDocument(m_doc.get(), m_undo);
    refreshPages();
    m_canvas->fitPage();
    onSelectionChanged();
    updateTitle();
}

void MainWindow::onDocChanged() {
    if (m_docChangePending) return;
    m_docChangePending = true;
    QTimer::singleShot(0, this, [this] {
        m_docChangePending = false;
        refreshPages();
        onSelectionChanged();
        updateTitle();
    });
}

void MainWindow::refreshPages() {
    if (!m_doc) return;
    const QSignalBlocker blocker(m_pageList);
    const int count = m_doc->pageCount();
    const int cur = qBound(0, m_canvas->currentPage(), count - 1);
    m_pageList->clear();
    for (int i = 0; i < count; ++i) m_pageList->addItem(tr("Page %1").arg(i + 1));
    m_pageList->setCurrentRow(cur);
    m_pageLabel->setText(tr("Page %1 / %2").arg(cur + 1).arg(count));
}

void MainWindow::onSelectionChanged() {
    if (!m_doc) return;
    const QStringList ids = m_canvas->selectedIds();
    const Object* o = (ids.size() == 1) ? m_doc->object(ids.first()) : nullptr;
    const bool editable = o && m_doc->canEdit(o->id);
    m_props->setObject(editable ? o : nullptr, m_doc->setup().displayUnit);
}

void MainWindow::onPropertyEdited(const Object& after) {
    if (!m_doc || !m_doc->canEdit(after.id)) return;
    const Object* before = m_doc->object(after.id);
    if (!before) return;
    m_undo->push(new ModifyObjectCommand(m_doc.get(), *before, after, tr("Change Properties")));
}

void MainWindow::updateTitle() {
    if (!m_doc) return;
    const QString n = m_path.isEmpty() ? m_doc->name() : QFileInfo(m_path).fileName();
    setWindowTitle(n + (isModified() ? QStringLiteral("*") : QString()) +
                   QStringLiteral(" - TRIONEX Publisher"));
}

// ------------------------------------------------------------------ files

bool MainWindow::maybeSave() {
    if (!isModified()) return true;
    const auto r = QMessageBox::warning(this, tr("TRIONEX Publisher"),
                                        tr("The document has unsaved changes. Save them?"),
                                        QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
    if (r == QMessageBox::Save) return save();
    return r == QMessageBox::Discard;
}

void MainWindow::newDocument() {
    if (!maybeSave()) return;
    NewDocumentDialog dlg(this);
    if (dlg.exec() != QDialog::Accepted) return;
    clearRecovery();
    setDocument(makeBlank(dlg.docName(), dlg.setup(), dlg.pageCount()), QString());
}

void MainWindow::openDocument() {
    if (!maybeSave()) return;
    const QString dir = QSettings().value("lastDir", QDir::homePath()).toString();
    const QString path = QFileDialog::getOpenFileName(this, tr("Open"), dir,
                                                      tr("TRIONEX Publication (*.txpub)"));
    if (!path.isEmpty()) openPath(path);
}

void MainWindow::openPath(const QString& path) {
    QString err;
    auto d = loadPackage(path, &err);
    if (!d) {
        QMessageBox::critical(this, tr("Open"), tr("Could not open %1:\n%2").arg(path, err));
        return;
    }
    QSettings().setValue("lastDir", QFileInfo(path).absolutePath());
    clearRecovery();
    setDocument(std::move(d), path);
    addRecent(path);
}

bool MainWindow::save() { return m_path.isEmpty() ? saveAs() : saveTo(m_path); }

bool MainWindow::saveAs() {
    const QString dir = QSettings().value("lastDir", QDir::homePath()).toString();
    QString path = QFileDialog::getSaveFileName(
        this, tr("Save As"), dir + "/" + m_doc->name() + ".txpub", tr("TRIONEX Publication (*.txpub)"));
    if (path.isEmpty()) return false;
    if (!path.endsWith(".txpub", Qt::CaseInsensitive)) path += ".txpub";
    return saveTo(path);
}

bool MainWindow::saveTo(const QString& path) {
    QString err;
    if (!savePackage(*m_doc, path, &err)) {
        QMessageBox::critical(this, tr("Save"), tr("Could not save:\n%1").arg(err));
        return false;
    }
    m_path = path;
    m_recovered = false;
    m_undo->setClean();
    clearRecovery();
    QSettings().setValue("lastDir", QFileInfo(path).absolutePath());
    addRecent(path);
    updateTitle();
    statusBar()->showMessage(tr("Saved %1").arg(path), 4000);
    return true;
}

void MainWindow::exportPdf() {
    const QString dir = QSettings().value("lastDir", QDir::homePath()).toString();
    QString path = QFileDialog::getSaveFileName(this, tr("Export PDF"),
                                                dir + "/" + m_doc->name() + ".pdf", tr("PDF (*.pdf)"));
    if (path.isEmpty()) return;
    if (!path.endsWith(".pdf", Qt::CaseInsensitive)) path += ".pdf";
    QString err;
    if (!trionex::exportPdf(*m_doc, path, &err))
        QMessageBox::critical(this, tr("Export PDF"), err);
    else
        statusBar()->showMessage(tr("Exported %1").arg(path), 4000);
}

void MainWindow::addPage() {
    const int at = m_canvas->currentPage() + 1;
    m_undo->push(new AddPageCommand(m_doc.get(), at, Page{Document::newId(), {}}));
    m_canvas->setCurrentPage(at);
}

void MainWindow::deletePage() {
    if (m_doc->pageCount() <= 1) {
        QMessageBox::information(this, tr("Delete Page"), tr("A document needs at least one page."));
        return;
    }
    m_undo->push(new DeletePageCommand(m_doc.get(), m_canvas->currentPage()));
}

// -------------------------------------------------------- recent / recovery

void MainWindow::addRecent(const QString& path) {
    QSettings s;
    QStringList r = s.value("recent").toStringList();
    r.removeAll(path);
    r.prepend(path);
    while (r.size() > 8) r.removeLast();
    s.setValue("recent", r);
    updateRecentMenu();
}

void MainWindow::updateRecentMenu() {
    m_recentMenu->clear();
    for (const QString& p : QSettings().value("recent").toStringList()) {
        QAction* a = m_recentMenu->addAction(p);
        connect(a, &QAction::triggered, this, [this, p] {
            if (maybeSave()) openPath(p);
        });
    }
    m_recentMenu->setEnabled(!m_recentMenu->isEmpty());
}

QString MainWindow::recoveryDir() const {
    return QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/recovery";
}

void MainWindow::autosave() {
    if (!m_doc || !isModified()) return;
    QDir().mkpath(recoveryDir());
    QString err;
    // Never touches the user's saved file; only the separate recovery copy.
    if (savePackage(*m_doc, recoveryDir() + "/autosave.txpub", &err)) {
        QSaveFile meta(recoveryDir() + "/autosave.json");
        if (meta.open(QIODevice::WriteOnly)) {
            QJsonObject o;
            o["originalPath"] = m_path;
            meta.write(QJsonDocument(o).toJson());
            meta.commit();
        }
    }
}

void MainWindow::clearRecovery() {
    QFile::remove(recoveryDir() + "/autosave.txpub");
    QFile::remove(recoveryDir() + "/autosave.json");
}

void MainWindow::checkRecovery() {
    const QString f = recoveryDir() + "/autosave.txpub";
    if (!QFileInfo::exists(f)) return;
    const auto r = QMessageBox::question(
        this, tr("Recover"),
        tr("TRIONEX Publisher did not close normally last time.\nRecover the unsaved work as a new "
           "untitled document? (Your last saved file will not be changed.)"));
    if (r != QMessageBox::Yes) {
        clearRecovery();
        return;
    }
    QString err;
    auto d = loadPackage(f, &err);
    if (!d) {
        QMessageBox::warning(this, tr("Recover"), tr("The recovery file could not be read:\n%1").arg(err));
        clearRecovery();
        return;
    }
    setDocument(std::move(d), QString(), /*recovered=*/true);
}

void MainWindow::closeEvent(QCloseEvent* e) {
    if (!maybeSave()) {
        e->ignore();
        return;
    }
    clearRecovery();
    e->accept();
}

} // namespace trionex
