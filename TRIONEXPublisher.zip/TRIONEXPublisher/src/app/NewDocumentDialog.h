#pragma once
#include <QCheckBox>
#include <QComboBox>
#include <QDialog>
#include <QDoubleSpinBox>
#include <QLineEdit>
#include <QSpinBox>
#include "core/Document.h"

namespace trionex {

class NewDocumentDialog : public QDialog {
    Q_OBJECT
public:
    explicit NewDocumentDialog(QWidget* parent = nullptr);
    QString docName() const { return m_name->text().trimmed(); }
    int pageCount() const { return m_pages->value(); }
    PageSetup setup() const;
    void accept() override;

private:
    Unit unit() const;
    void applyPreset();
    void onUnitChanged();
    QDoubleSpinBox* mkSpin(double def);

    QLineEdit* m_name;
    QComboBox *m_unit, *m_preset, *m_orient;
    QDoubleSpinBox *m_w, *m_h, *m_mt, *m_mb, *m_ml, *m_mr, *m_bleed, *m_gutter;
    QSpinBox *m_pages, *m_cols;
    QCheckBox* m_facing;
    Unit m_prevUnit = Unit::Millimetre;
};

} // namespace trionex
