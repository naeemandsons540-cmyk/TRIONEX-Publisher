#pragma once
#include <QGraphicsPathItem>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QUndoStack>
#include "core/Document.h"

namespace trionex {

enum class Tool { Select, Rectangle, Ellipse, Line };

class CanvasView : public QGraphicsView {
    Q_OBJECT
public:
    explicit CanvasView(QWidget* parent = nullptr);

    void setDocument(Document* doc, QUndoStack* undo);
    void setCurrentPage(int index);
    int currentPage() const { return m_page; }
    void setTool(Tool t);

    QStringList selectedIds() const;
    void selectAll();
    void deleteSelection();
    void nudgeSelection(double dx, double dy);
    void arrangeSelection(bool toFront);
    void setSelectionLocked(bool locked);

    void zoomBy(double factor);
    void fitPage();

signals:
    void selectionChanged();
    void zoomChanged(double zoom);
    void toolFinished();

protected:
    void mousePressEvent(QMouseEvent* e) override;
    void mouseMoveEvent(QMouseEvent* e) override;
    void mouseReleaseEvent(QMouseEvent* e) override;
    void wheelEvent(QWheelEvent* e) override;
    void keyPressEvent(QKeyEvent* e) override;
    void showEvent(QShowEvent* e) override;

private:
    void scheduleRebuild();
    void rebuild();
    void commitGeometryChanges();
    void applyChanges(const QVector<Object>& afters, const QString& text);
    QPainterPath previewPath(const QPointF& a, const QPointF& b) const;

    QGraphicsScene* m_scene;
    Document* m_doc = nullptr;
    QUndoStack* m_undo = nullptr;
    int m_page = 0;
    Tool m_tool = Tool::Select;
    bool m_rebuildPending = false;
    bool m_rebuilding = false;
    QStringList m_pendingSelect;

    bool m_drawing = false;
    QPointF m_drawStart;
    QGraphicsPathItem* m_preview = nullptr;
    bool m_panning = false;
    QPoint m_panLast;
    bool m_fitOnShow = true;
};

} // namespace trionex
