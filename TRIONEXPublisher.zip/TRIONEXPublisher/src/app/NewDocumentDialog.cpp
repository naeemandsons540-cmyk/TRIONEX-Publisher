#include "NewDocumentDialog.h"

#include <QDialogButtonBox>
#include <QFormLayout>
#include <QMessageBox>
#include <QSignalBlocker>
#include <QVBoxLayout>
#include <iterator>
#include <utility>

namespace trionex {

namespace {
struct Preset {
    const char* name;
    double wMm, hMm;
};
const Preset kPresets[] = {{"A4", 210, 297},        {"A5", 148, 210},
                           {"A3", 297, 420},        {"Letter", 215.9, 279.4},
                           {"Legal", 215.9, 355.6}, {"Custom", 0, 0}};
} // namespace

QDoubleSpinBox* NewDocumentDialog::mkSpin(double def) {
    auto* s = new QDoubleSpinBox(this);
    s->setRange(0, 100000);
    s->setDecimals(2);
    s->setValue(def);
    return s;
}

NewDocumentDialog::NewDocumentDialog(QWidget* parent) : QDialog(parent) {
    setWindowTitle(tr("New Document"));
    auto* form = new QFormLayout;
    m_name = new QLineEdit(tr("Untitled"), this);
    m_unit = new QComboBox(this);
    for (Unit u : {Unit::Millimetre, Unit::Centimetre, Unit::Inch, Unit::Point})
        m_unit->addItem(unitName(u), int(u));
    m_preset = new QComboBox(this);
    for (const Preset& p : kPresets) m_preset->addItem(p.name);
    m_orient = new QComboBox(this);
    m_orient->addItems({tr("Portrait"), tr("Landscape")});
    m_w = mkSpin(210);
    m_h = mkSpin(297);
    m_pages = new QSpinBox(this);
    m_pages->setRange(1, 500);
    m_pages->setValue(1);
    m_facing = new QCheckBox(tr("Facing pages"), this);
    m_mt = mkSpin(12.7);
    m_mb = mkSpin(12.7);
    m_ml = mkSpin(12.7);
    m_mr = mkSpin(12.7);
    m_bleed = mkSpin(0);
    m_cols = new QSpinBox(this);
    m_cols->setRange(1, 12);
    m_gutter = mkSpin(4.23);

    form->addRow(tr("Name"), m_name);
    form->addRow(tr("Units"), m_unit);
    form->addRow(tr("Page size"), m_preset);
    form->addRow(tr("Orientation"), m_orient);
    form->addRow(tr("Width"), m_w);
    form->addRow(tr("Height"), m_h);
    form->addRow(tr("Number of pages"), m_pages);
    form->addRow(QString(), m_facing);
    form->addRow(tr("Margin top"), m_mt);
    form->addRow(tr("Margin bottom"), m_mb);
    form->addRow(tr("Margin left"), m_ml);
    form->addRow(tr("Margin right"), m_mr);
    form->addRow(tr("Bleed"), m_bleed);
    form->addRow(tr("Columns"), m_cols);
    form->addRow(tr("Column gutter"), m_gutter);

    auto* box = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(box, &QDialogButtonBox::accepted, this, &NewDocumentDialog::accept);
    connect(box, &QDialogButtonBox::rejected, this, &QDialog::reject);
    auto* lay = new QVBoxLayout(this);
    lay->addLayout(form);
    lay->addWidget(box);

    connect(m_preset, &QComboBox::currentIndexChanged, this, [this] { applyPreset(); });
    connect(m_orient, &QComboBox::currentIndexChanged, this, [this] {
        if (m_preset->currentIndex() == int(std::size(kPresets)) - 1) {
            const QSignalBlocker b1(m_w), b2(m_h);
            const double w = m_w->value(), h = m_h->value();
            const bool land = m_orient->currentIndex() == 1;
            if ((land && w < h) || (!land && w > h)) {
                m_w->setValue(h);
                m_h->setValue(w);
            }
        } else {
            applyPreset();
        }
    });
    auto toCustom = [this] {
        const QSignalBlocker b(m_preset);
        m_preset->setCurrentIndex(int(std::size(kPresets)) - 1);
    };
    connect(m_w, &QDoubleSpinBox::valueChanged, this, toCustom);
    connect(m_h, &QDoubleSpinBox::valueChanged, this, toCustom);
    connect(m_unit, &QComboBox::currentIndexChanged, this, [this] { onUnitChanged(); });
    applyPreset();
}

Unit NewDocumentDialog::unit() const { return Unit(m_unit->currentData().toInt()); }

void NewDocumentDialog::applyPreset() {
    const Preset& p = kPresets[m_preset->currentIndex()];
    if (p.wMm <= 0) return;
    double w = p.wMm, h = p.hMm;
    if (m_orient->currentIndex() == 1) std::swap(w, h);
    const QSignalBlocker b1(m_w), b2(m_h);
    m_w->setValue(pointsToUnit(unitToPoints(w, Unit::Millimetre), unit()));
    m_h->setValue(pointsToUnit(unitToPoints(h, Unit::Millimetre), unit()));
}

void NewDocumentDialog::onUnitChanged() {
    const Unit from = m_prevUnit, to = unit();
    for (auto* s : {m_w, m_h, m_mt, m_mb, m_ml, m_mr, m_bleed, m_gutter}) {
        const QSignalBlocker b(s);
        s->setValue(pointsToUnit(unitToPoints(s->value(), from), to));
    }
    m_prevUnit = to;
}

PageSetup NewDocumentDialog::setup() const {
    const Unit u = unit();
    PageSetup s;
    s.displayUnit = u;
    s.width = unitToPoints(m_w->value(), u);
    s.height = unitToPoints(m_h->value(), u);
    s.marginTop = unitToPoints(m_mt->value(), u);
    s.marginBottom = unitToPoints(m_mb->value(), u);
    s.marginLeft = unitToPoints(m_ml->value(), u);
    s.marginRight = unitToPoints(m_mr->value(), u);
    s.bleed = unitToPoints(m_bleed->value(), u);
    s.columns = m_cols->value();
    s.gutter = unitToPoints(m_gutter->value(), u);
    s.facingPages = m_facing->isChecked();
    return s;
}

void NewDocumentDialog::accept() {
    if (docName().isEmpty()) {
        QMessageBox::warning(this, tr("New Document"), tr("Please enter a document name."));
        return;
    }
    const QString err = Document::validateSetup(setup());
    if (!err.isEmpty()) {
        QMessageBox::warning(this, tr("New Document"), err);
        return;
    }
    QDialog::accept();
}

} // namespace trionex
