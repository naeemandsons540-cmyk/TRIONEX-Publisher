#include <QApplication>
#include <QPalette>
#include <QStyleFactory>

#include "MainWindow.h"
#include "core/Document.h"

static void applyDarkTheme(QApplication& app) {
    app.setStyle(QStyleFactory::create("Fusion"));
    QPalette p;
    p.setColor(QPalette::Window, QColor(45, 45, 48));
    p.setColor(QPalette::WindowText, QColor(225, 225, 225));
    p.setColor(QPalette::Base, QColor(30, 30, 32));
    p.setColor(QPalette::AlternateBase, QColor(45, 45, 48));
    p.setColor(QPalette::Text, QColor(225, 225, 225));
    p.setColor(QPalette::Button, QColor(60, 60, 64));
    p.setColor(QPalette::ButtonText, QColor(225, 225, 225));
    p.setColor(QPalette::ToolTipBase, QColor(60, 60, 64));
    p.setColor(QPalette::ToolTipText, QColor(225, 225, 225));
    p.setColor(QPalette::Highlight, QColor(0, 120, 215));
    p.setColor(QPalette::HighlightedText, Qt::white);
    p.setColor(QPalette::Disabled, QPalette::Text, QColor(120, 120, 120));
    p.setColor(QPalette::Disabled, QPalette::ButtonText, QColor(120, 120, 120));
    app.setPalette(p);
}

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    QApplication::setOrganizationName("TRIONEX");
    QApplication::setApplicationName("TRIONEX Publisher");
    QApplication::setApplicationVersion(QString::fromLatin1(trionex::kAppVersion));
    applyDarkTheme(app);

    trionex::MainWindow w;
    w.show();
    const QStringList args = app.arguments();
    if (args.size() > 1) w.openPath(args.at(1));
    return app.exec();
}
