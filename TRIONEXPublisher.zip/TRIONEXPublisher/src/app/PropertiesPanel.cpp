#include "PropertiesPanel.h"

#include <QColorDialog>
#include <QFormLayout>
#include <QLabel>
#include <QVBoxLayout>

namespace trionex {

PropertiesPanel::PropertiesPanel(QWidget* parent) : QWidget(parent) {
    auto* outer = new QVBoxLayout(this);
    auto* form = new QFormLayout;
    auto mkSpin = [this](double lo, double hi) {
        auto* s = new QDoubleSpinBox(this);
        s->setRange(lo, hi);
        s->setDecimals(2);
        s->setKeyboardTracking(false);
        connect(s, &QDoubleSpinBox::valueChanged, this, [this] { emitEdited(); });
        return s;
    };
    m_x = mkSpin(-100000, 100000);
    m_y = mkSpin(-100000, 100000);
    m_w = mkSpin(-100000, 100000);
    m_h = mkSpin(-100000, 100000);
    m_sw = mkSpin(0, 1000);
    m_sw->setSuffix(" pt");
    m_fill = new QPushButton(this);
    m_stroke = new QPushButton(this);
    connect(m_fill, &QPushButton::clicked, this, [this] { pickColor(true); });
    connect(m_stroke, &QPushButton::clicked, this, [this] { pickColor(false); });
    form->addRow(tr("X"), m_x);
    form->addRow(tr("Y"), m_y);
    form->addRow(tr("Width"), m_w);
    form->addRow(tr("Height"), m_h);
    form->addRow(tr("Fill"), m_fill);
    form->addRow(tr("Stroke"), m_stroke);
    form->addRow(tr("Stroke width"), m_sw);
    outer->addLayout(form);
    outer->addStretch(1);
    setObject(nullptr, m_unit);
}

void PropertiesPanel::setObject(const Object* o, Unit unit) {
    m_loading = true;
    m_unit = unit;
    m_has = (o != nullptr);
    setEnabled(m_has);
    if (o) m_obj = *o;
    const QString suf = QStringLiteral(" ") + unitName(unit);
    for (auto* s : {m_x, m_y, m_w, m_h}) s->setSuffix(suf);
    m_x->setValue(m_has ? pointsToUnit(m_obj.x, unit) : 0);
    m_y->setValue(m_has ? pointsToUnit(m_obj.y, unit) : 0);
    m_w->setValue(m_has ? pointsToUnit(m_obj.w, unit) : 0);
    m_h->setValue(m_has ? pointsToUnit(m_obj.h, unit) : 0);
    m_sw->setValue(m_has ? m_obj.strokeWidth : 0);
    refreshButtons();
    m_loading = false;
}

void PropertiesPanel::refreshButtons() {
    auto style = [](const QColor& c) {
        return QStringLiteral("background-color: %1; min-height: 20px;").arg(c.name());
    };
    m_fill->setStyleSheet(m_has ? style(m_obj.fill) : QString());
    m_stroke->setStyleSheet(m_has ? style(m_obj.stroke) : QString());
}

void PropertiesPanel::emitEdited() {
    if (!m_has || m_loading) return;
    Object o = m_obj;
    o.x = unitToPoints(m_x->value(), m_unit);
    o.y = unitToPoints(m_y->value(), m_unit);
    o.w = unitToPoints(m_w->value(), m_unit);
    o.h = unitToPoints(m_h->value(), m_unit);
    if (o.type != ObjectType::Line) {
        o.w = qMax(1.0, o.w);
        o.h = qMax(1.0, o.h);
    }
    o.strokeWidth = m_sw->value();
    emit edited(o);
}

void PropertiesPanel::pickColor(bool fill) {
    if (!m_has) return;
    const QColor c = QColorDialog::getColor(fill ? m_obj.fill : m_obj.stroke, this,
                                            fill ? tr("Fill colour") : tr("Stroke colour"),
                                            QColorDialog::ShowAlphaChannel);
    if (!c.isValid()) return;
    Object o = m_obj;
    (fill ? o.fill : o.stroke) = c;
    emit edited(o);
}

} // namespace trionex
