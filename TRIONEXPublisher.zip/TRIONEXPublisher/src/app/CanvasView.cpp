#include "CanvasView.h"

#include <QGraphicsSceneMouseEvent>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QPainter>
#include <QPainterPathStroker>
#include <QScrollBar>
#include <QTimer>
#include <QWheelEvent>
#include <cmath>

#include "core/Commands.h"
#include "core/Render.h"

namespace trionex {

namespace {

// A document object on the canvas. Edits (move/resize) happen on the item and are
// committed to the document as undoable commands by CanvasView on mouse release.
class ObjectItem : public QGraphicsItem {
public:
    ObjectItem(const Object& o, bool editable) : m_obj(o), m_editable(editable) {
        setPos(o.x, o.y);
        setFlag(ItemIsSelectable, true);
        if (editable) setFlag(ItemIsMovable, true);
        setAcceptedMouseButtons(Qt::LeftButton);
    }

    const QString& id() const { return m_obj.id; }
    Object current() const {
        Object o = m_obj;
        o.x = pos().x();
        o.y = pos().y();
        return o;
    }

    QRectF boundingRect() const override {
        return QRectF(0, 0, m_obj.w, m_obj.h).normalized().adjusted(-60, -60, 60, 60);
    }

    QPainterPath shape() const override {
        QPainterPath p;
        const QRectF r = QRectF(0, 0, m_obj.w, m_obj.h).normalized();
        if (m_obj.type == ObjectType::Line) {
            QPainterPath l;
            l.moveTo(0, 0);
            l.lineTo(m_obj.w, m_obj.h);
            QPainterPathStroker s;
            s.setWidth(qMax(m_obj.strokeWidth, 6.0));
            p = s.createStroke(l);
        } else if (m_obj.type == ObjectType::Ellipse) {
            p.addEllipse(r);
        } else {
            p.addRect(r);
        }
        if (isSelected() && m_editable)
            for (const QRectF& h : handleRects()) p.addRect(h);
        return p;
    }

    void paint(QPainter* painter, const QStyleOptionGraphicsItem*, QWidget*) override {
        paintObject(painter, m_obj);
        if (!isSelected()) return;
        painter->save();
        painter->setBrush(Qt::NoBrush);
        painter->setPen(QPen(QColor(0, 120, 215), 0, Qt::DashLine));
        painter->drawRect(QRectF(0, 0, m_obj.w, m_obj.h).normalized());
        if (m_editable) {
            painter->setBrush(Qt::white);
            painter->setPen(QPen(QColor(0, 120, 215), 0));
            for (const QRectF& h : handleRects()) painter->drawRect(h);
        }
        painter->restore();
    }

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent* e) override {
        if (m_editable && isSelected() && e->button() == Qt::LeftButton) {
            const auto hr = handleRects();
            for (int i = 0; i < hr.size(); ++i) {
                if (!hr[i].adjusted(-2, -2, 2, 2).contains(e->pos())) continue;
                m_handle = i;
                const QRectF r(pos(), QSizeF(m_obj.w, m_obj.h));
                if (m_obj.type == ObjectType::Line)
                    m_fixed = (i == 0) ? pos() + QPointF(m_obj.w, m_obj.h) : pos();
                else
                    m_fixed = (i == 0) ? r.bottomRight()
                              : (i == 1) ? r.bottomLeft()
                              : (i == 2) ? r.topRight()
                                         : r.topLeft();
                e->accept();
                return;
            }
        }
        QGraphicsItem::mousePressEvent(e);
    }

    void mouseMoveEvent(QGraphicsSceneMouseEvent* e) override {
        if (m_handle < 0) {
            QGraphicsItem::mouseMoveEvent(e);
            return;
        }
        const QPointF p = e->scenePos();
        prepareGeometryChange();
        if (m_obj.type == ObjectType::Line) {
            const QPointF a = (m_handle == 0) ? p : m_fixed;
            const QPointF b = (m_handle == 0) ? m_fixed : p;
            setPos(a);
            m_obj.w = b.x() - a.x();
            m_obj.h = b.y() - a.y();
        } else {
            QRectF r = QRectF(m_fixed, p).normalized();
            if (r.width() < 1) r.setWidth(1);
            if (r.height() < 1) r.setHeight(1);
            setPos(r.topLeft());
            m_obj.w = r.width();
            m_obj.h = r.height();
        }
        update();
    }

    void mouseReleaseEvent(QGraphicsSceneMouseEvent* e) override {
        if (m_handle >= 0) {
            m_handle = -1;
            e->accept();
            return;
        }
        QGraphicsItem::mouseReleaseEvent(e);
    }

private:
    double zoom() const {
        if (!scene() || scene()->views().isEmpty()) return 1.0;
        return scene()->views().first()->transform().m11();
    }
    QVector<QRectF> handleRects() const {
        const double s = 9.0 / zoom();
        auto at = [s](double x, double y) { return QRectF(x - s / 2, y - s / 2, s, s); };
        if (m_obj.type == ObjectType::Line) return {at(0, 0), at(m_obj.w, m_obj.h)};
        return {at(0, 0), at(m_obj.w, 0), at(0, m_obj.h), at(m_obj.w, m_obj.h)};
    }

    Object m_obj;
    bool m_editable;
    int m_handle = -1;
    QPointF m_fixed;
};

bool geometryDiffers(const Object& a, const Object& b) {
    auto d = [](double u, double v) { return std::fabs(u - v) > 1e-6; };
    return d(a.x, b.x) || d(a.y, b.y) || d(a.w, b.w) || d(a.h, b.h);
}

} // namespace

CanvasView::CanvasView(QWidget* parent) : QGraphicsView(parent) {
    m_scene = new QGraphicsScene(this);
    setScene(m_scene);
    setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing);
    setBackgroundBrush(QColor(58, 58, 60));
    setTransformationAnchor(AnchorUnderMouse);
    setResizeAnchor(AnchorViewCenter);
    setDragMode(RubberBandDrag);
    setViewportUpdateMode(FullViewportUpdate);
    setFocusPolicy(Qt::StrongFocus);
    connect(m_scene, &QGraphicsScene::selectionChanged, this, [this] {
        if (!m_rebuilding) emit selectionChanged();
    });
}

void CanvasView::setDocument(Document* doc, QUndoStack* undo) {
    if (m_doc) disconnect(m_doc, nullptr, this, nullptr);
    m_doc = doc;
    m_undo = undo;
    m_page = 0;
    if (!isVisible()) m_fitOnShow = true;
    if (m_doc)
        connect(m_doc, &Document::changed, this, &CanvasView::scheduleRebuild,
                Qt::QueuedConnection);
    rebuild();
}

void CanvasView::setCurrentPage(int index) {
    m_page = index;
    rebuild();
}

void CanvasView::setTool(Tool t) {
    m_tool = t;
    setDragMode(t == Tool::Select ? RubberBandDrag : NoDrag);
    viewport()->setCursor(t == Tool::Select ? Qt::ArrowCursor : Qt::CrossCursor);
}

void CanvasView::scheduleRebuild() {
    if (m_rebuildPending) return;
    m_rebuildPending = true;
    QTimer::singleShot(0, this, &CanvasView::rebuild);
}

void CanvasView::rebuild() {
    m_rebuildPending = false;
    QStringList keep = selectedIds();
    if (!m_pendingSelect.isEmpty()) {
        keep = m_pendingSelect;
        m_pendingSelect.clear();
    }
    m_rebuilding = true;
    m_preview = nullptr;
    m_scene->clear();
    if (!m_doc || m_doc->pageCount() == 0) {
        m_rebuilding = false;
        emit selectionChanged();
        return;
    }
    m_page = qBound(0, m_page, m_doc->pageCount() - 1);
    const PageSetup& s = m_doc->setup();
    m_scene->setSceneRect(-300, -300, s.width + 600, s.height + 600);

    auto* shadow = m_scene->addRect(QRectF(5, 5, s.width, s.height), Qt::NoPen, QColor(0, 0, 0, 70));
    shadow->setZValue(-1000);
    auto* paper = m_scene->addRect(QRectF(0, 0, s.width, s.height), QPen(QColor(90, 90, 90), 0),
                                   Qt::white);
    paper->setZValue(-999);
    if (s.bleed > 0) {
        auto* b = m_scene->addRect(QRectF(-s.bleed, -s.bleed, s.width + 2 * s.bleed,
                                          s.height + 2 * s.bleed),
                                   QPen(QColor(230, 60, 60), 0, Qt::DashLine));
        b->setZValue(-998);
    }
    const QRectF mr(s.marginLeft, s.marginTop, s.width - s.marginLeft - s.marginRight,
                    s.height - s.marginTop - s.marginBottom);
    auto* margins = m_scene->addRect(mr, QPen(QColor(0, 170, 255), 0, Qt::DotLine));
    margins->setZValue(-997);
    if (s.columns > 1) {
        const double cw = (mr.width() - s.gutter * (s.columns - 1)) / s.columns;
        for (int c = 0; c < s.columns; ++c) {
            auto* col = m_scene->addRect(QRectF(mr.left() + c * (cw + s.gutter), mr.top(), cw,
                                                mr.height()),
                                         QPen(QColor(200, 120, 255), 0, Qt::DotLine));
            col->setZValue(-996);
        }
    }

    const Page& pg = m_doc->page(m_page);
    for (int i = 0; i < pg.objects.size(); ++i) {
        const Object& o = pg.objects[i];
        if (!m_doc->isLayerVisible(o.layerId)) continue;
        auto* item = new ObjectItem(o, m_doc->canEdit(o.id));
        item->setZValue(i);
        m_scene->addItem(item);
        if (keep.contains(o.id)) item->setSelected(true);
    }
    m_rebuilding = false;
    emit selectionChanged();
}

QStringList CanvasView::selectedIds() const {
    QStringList ids;
    for (QGraphicsItem* gi : m_scene->selectedItems())
        if (auto* it = dynamic_cast<ObjectItem*>(gi)) ids << it->id();
    return ids;
}

void CanvasView::selectAll() {
    for (QGraphicsItem* gi : m_scene->items())
        if (dynamic_cast<ObjectItem*>(gi)) gi->setSelected(true);
}

void CanvasView::applyChanges(const QVector<Object>& afters, const QString& text) {
    if (!m_doc || !m_undo || afters.isEmpty()) return;
    if (afters.size() > 1) m_undo->beginMacro(text);
    for (const Object& a : afters)
        if (const Object* before = m_doc->object(a.id))
            m_undo->push(new ModifyObjectCommand(m_doc, *before, a, text));
    if (afters.size() > 1) m_undo->endMacro();
}

void CanvasView::commitGeometryChanges() {
    if (!m_doc) return;
    QVector<Object> afters;
    for (QGraphicsItem* gi : m_scene->items()) {
        auto* it = dynamic_cast<ObjectItem*>(gi);
        if (!it) continue;
        const Object cur = it->current();
        const Object* orig = m_doc->object(cur.id);
        if (orig && m_doc->canEdit(cur.id) && geometryDiffers(*orig, cur)) afters << cur;
    }
    applyChanges(afters, tr("Move/Resize"));
}

void CanvasView::deleteSelection() {
    if (!m_doc || !m_undo) return;
    QStringList ids;
    for (const QString& id : selectedIds())
        if (m_doc->canEdit(id)) ids << id;
    if (!ids.isEmpty()) m_undo->push(new DeleteObjectsCommand(m_doc, ids));
}

void CanvasView::nudgeSelection(double dx, double dy) {
    if (!m_doc) return;
    QVector<Object> afters;
    for (const QString& id : selectedIds()) {
        if (!m_doc->canEdit(id)) continue;
        Object o = *m_doc->object(id);
        o.x += dx;
        o.y += dy;
        afters << o;
    }
    applyChanges(afters, tr("Nudge"));
}

void CanvasView::arrangeSelection(bool toFront) {
    if (!m_doc || !m_undo) return;
    QStringList ids;
    for (const QString& id : selectedIds())
        if (m_doc->canEdit(id)) ids << id;
    if (ids.isEmpty()) return;
    if (ids.size() > 1) m_undo->beginMacro(toFront ? tr("Bring to Front") : tr("Send to Back"));
    for (const QString& id : ids) m_undo->push(new ArrangeCommand(m_doc, id, toFront));
    if (ids.size() > 1) m_undo->endMacro();
    m_pendingSelect = ids;
}

void CanvasView::setSelectionLocked(bool locked) {
    if (!m_doc) return;
    QVector<Object> afters;
    for (const QString& id : selectedIds()) {
        Object o = *m_doc->object(id);
        if (o.locked == locked) continue;
        o.locked = locked;
        afters << o;
    }
    applyChanges(afters, locked ? tr("Lock") : tr("Unlock"));
}

void CanvasView::zoomBy(double factor) {
    const double cur = transform().m11();
    const double target = qBound(0.1, cur * factor, 16.0);
    const double f = target / cur;
    scale(f, f);
    emit zoomChanged(transform().m11());
}

void CanvasView::fitPage() {
    if (!m_doc) return;
    const PageSetup& s = m_doc->setup();
    fitInView(QRectF(-20, -20, s.width + 40, s.height + 40), Qt::KeepAspectRatio);
    const double z = transform().m11();
    if (z > 16.0 || z < 0.1) zoomBy(qBound(0.1, z, 16.0) / z);
    emit zoomChanged(transform().m11());
}

void CanvasView::showEvent(QShowEvent* e) {
    QGraphicsView::showEvent(e);
    if (m_fitOnShow) {
        m_fitOnShow = false;
        fitPage();
    }
}

QPainterPath CanvasView::previewPath(const QPointF& a, const QPointF& b) const {
    QPainterPath p;
    if (m_tool == Tool::Line) {
        p.moveTo(a);
        p.lineTo(b);
    } else if (m_tool == Tool::Ellipse) {
        p.addEllipse(QRectF(a, b).normalized());
    } else {
        p.addRect(QRectF(a, b).normalized());
    }
    return p;
}

void CanvasView::mousePressEvent(QMouseEvent* e) {
    if (e->button() == Qt::MiddleButton) {
        m_panning = true;
        m_panLast = e->pos();
        viewport()->setCursor(Qt::ClosedHandCursor);
        e->accept();
        return;
    }
    if (m_tool != Tool::Select && e->button() == Qt::LeftButton && m_doc) {
        m_drawing = true;
        m_drawStart = mapToScene(e->pos());
        m_preview = m_scene->addPath(QPainterPath(), QPen(QColor(0, 120, 215), 0, Qt::DashLine));
        m_preview->setZValue(1e6);
        e->accept();
        return;
    }
    QGraphicsView::mousePressEvent(e);
}

void CanvasView::mouseMoveEvent(QMouseEvent* e) {
    if (m_panning) {
        const QPoint d = e->pos() - m_panLast;
        m_panLast = e->pos();
        horizontalScrollBar()->setValue(horizontalScrollBar()->value() - d.x());
        verticalScrollBar()->setValue(verticalScrollBar()->value() - d.y());
        e->accept();
        return;
    }
    if (m_drawing && m_preview) {
        m_preview->setPath(previewPath(m_drawStart, mapToScene(e->pos())));
        e->accept();
        return;
    }
    QGraphicsView::mouseMoveEvent(e);
}

void CanvasView::mouseReleaseEvent(QMouseEvent* e) {
    if (m_panning && e->button() == Qt::MiddleButton) {
        m_panning = false;
        viewport()->setCursor(m_tool == Tool::Select ? Qt::ArrowCursor : Qt::CrossCursor);
        e->accept();
        return;
    }
    if (m_drawing && e->button() == Qt::LeftButton) {
        m_drawing = false;
        const QPointF a = m_drawStart, b = mapToScene(e->pos());
        if (m_preview) {
            m_scene->removeItem(m_preview);
            delete m_preview;
            m_preview = nullptr;
        }
        Object o;
        o.id = Document::newId();
        o.layerId = m_doc->defaultLayerId();
        bool ok = false;
        if (m_tool == Tool::Line) {
            if (QLineF(a, b).length() >= 2) {
                o.type = ObjectType::Line;
                o.x = a.x();
                o.y = a.y();
                o.w = b.x() - a.x();
                o.h = b.y() - a.y();
                o.fill = Qt::transparent;
                ok = true;
            }
        } else {
            const QRectF r = QRectF(a, b).normalized();
            if (r.width() >= 2 && r.height() >= 2) {
                o.type = (m_tool == Tool::Ellipse) ? ObjectType::Ellipse : ObjectType::Rectangle;
                o.x = r.x();
                o.y = r.y();
                o.w = r.width();
                o.h = r.height();
                ok = true;
            }
        }
        if (ok) {
            m_pendingSelect = {o.id};
            m_undo->push(new AddObjectCommand(m_doc, m_page, o));
        }
        emit toolFinished();
        e->accept();
        return;
    }
    QGraphicsView::mouseReleaseEvent(e);
    if (e->button() == Qt::LeftButton) commitGeometryChanges();
}

void CanvasView::wheelEvent(QWheelEvent* e) {
    if (e->modifiers() & Qt::ControlModifier) {
        zoomBy(std::pow(1.15, e->angleDelta().y() / 120.0));
        e->accept();
        return;
    }
    QGraphicsView::wheelEvent(e);
}

void CanvasView::keyPressEvent(QKeyEvent* e) {
    const double step = (e->modifiers() & Qt::ShiftModifier) ? 10.0 : 1.0;
    switch (e->key()) {
    case Qt::Key_Delete:
    case Qt::Key_Backspace: deleteSelection(); return;
    case Qt::Key_Left: nudgeSelection(-step, 0); return;
    case Qt::Key_Right: nudgeSelection(step, 0); return;
    case Qt::Key_Up: nudgeSelection(0, -step); return;
    case Qt::Key_Down: nudgeSelection(0, step); return;
    default: QGraphicsView::keyPressEvent(e);
    }
}

} // namespace trionex
