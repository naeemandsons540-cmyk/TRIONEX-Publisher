#pragma once
#include <QDoubleSpinBox>
#include <QPushButton>
#include <QWidget>
#include "core/Document.h"

namespace trionex {

class PropertiesPanel : public QWidget {
    Q_OBJECT
public:
    explicit PropertiesPanel(QWidget* parent = nullptr);
    // Pass nullptr to show "nothing selected".
    void setObject(const Object* o, Unit unit);

signals:
    void edited(const trionex::Object& after);

private:
    void emitEdited();
    void pickColor(bool fill);
    void refreshButtons();

    QDoubleSpinBox *m_x, *m_y, *m_w, *m_h, *m_sw;
    QPushButton *m_fill, *m_stroke;
    Object m_obj;
    Unit m_unit = Unit::Millimetre;
    bool m_has = false;
    bool m_loading = false;
};

} // namespace trionex
