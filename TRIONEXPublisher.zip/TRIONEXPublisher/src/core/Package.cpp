#include "Package.h"

#include <QCryptographicHash>
#include <QFile>
#include <QJsonDocument>
#include <QSaveFile>
#include <cstring>
#include <miniz.h>

namespace trionex {

namespace {
constexpr size_t kMaxEntryBytes = 64u * 1024u * 1024u; // zip-bomb guard
constexpr mz_uint kMaxEntries = 100000;

bool isAllowedDir(const QString& s) {
    return s == QLatin1String("assets") || s == QLatin1String("previews") ||
           s == QLatin1String("metadata");
}
} // namespace

bool isSafeEntryName(const QString& n) {
    if (n.isEmpty() || n.size() > 240) return false;
    if (n.contains(QLatin1Char('\\')) || n.contains(QLatin1Char(':')) ||
        n.startsWith(QLatin1Char('/')))
        return false;
    for (QChar c : n)
        if (c.unicode() < 0x20) return false;
    QStringList parts = n.split(QLatin1Char('/'));
    if (parts.last().isEmpty()) parts.removeLast(); // directory entry
    if (parts.isEmpty()) return false;
    for (const QString& p : parts)
        if (p.isEmpty() || p == QLatin1String(".") || p == QLatin1String("..")) return false;
    if (parts.size() == 1)
        return parts[0] == QLatin1String("manifest.json") ||
               parts[0] == QLatin1String("document.json") || isAllowedDir(parts[0]);
    return isAllowedDir(parts[0]);
}

QByteArray buildPackageBytes(const Document& doc, QString* error) {
    const QByteArray docBytes = QJsonDocument(doc.toJson()).toJson(QJsonDocument::Indented);
    QJsonObject m;
    m["format"] = QStringLiteral("txpub");
    m["formatVersion"] = kFormatVersion;
    m["appVersion"] = QString::fromLatin1(kAppVersion);
    m["documentSha256"] =
        QString::fromLatin1(QCryptographicHash::hash(docBytes, QCryptographicHash::Sha256).toHex());
    const QByteArray manBytes = QJsonDocument(m).toJson(QJsonDocument::Indented);

    mz_zip_archive zip;
    std::memset(&zip, 0, sizeof(zip));
    if (!mz_zip_writer_init_heap(&zip, 0, 0)) {
        if (error) *error = QObject::tr("Could not start writing the package.");
        return {};
    }
    auto add = [&](const char* name, const QByteArray& b) {
        return mz_zip_writer_add_mem(&zip, name, b.constData(), size_t(b.size()), MZ_DEFAULT_LEVEL);
    };
    if (!add("manifest.json", manBytes) || !add("document.json", docBytes)) {
        mz_zip_writer_end(&zip);
        if (error) *error = QObject::tr("Could not add content to the package.");
        return {};
    }
    void* buf = nullptr;
    size_t sz = 0;
    if (!mz_zip_writer_finalize_heap_archive(&zip, &buf, &sz)) {
        mz_zip_writer_end(&zip);
        if (error) *error = QObject::tr("Could not finish the package.");
        return {};
    }
    QByteArray out(static_cast<const char*>(buf), qsizetype(sz));
    mz_free(buf);
    mz_zip_writer_end(&zip);
    return out;
}

std::unique_ptr<Document> loadPackageFromBytes(const QByteArray& bytes, QString* error) {
    auto fail = [&](const QString& m) {
        if (error) *error = m;
        return std::unique_ptr<Document>();
    };
    mz_zip_archive zip;
    std::memset(&zip, 0, sizeof(zip));
    if (!mz_zip_reader_init_mem(&zip, bytes.constData(), size_t(bytes.size()), 0))
        return fail(QObject::tr("This file is not a valid TRIONEX package (or is corrupted)."));
    struct Guard {
        mz_zip_archive* z;
        ~Guard() { mz_zip_reader_end(z); }
    } guard{&zip};

    const mz_uint n = mz_zip_reader_get_num_files(&zip);
    if (n == 0 || n > kMaxEntries) return fail(QObject::tr("The package has an invalid entry count."));
    for (mz_uint i = 0; i < n; ++i) {
        mz_zip_archive_file_stat st;
        if (!mz_zip_reader_file_stat(&zip, i, &st))
            return fail(QObject::tr("The package directory is corrupted."));
        if (!isSafeEntryName(QString::fromUtf8(st.m_filename)))
            return fail(QObject::tr("The package contains an unsafe or unknown entry and was rejected."));
        if (st.m_uncomp_size > kMaxEntryBytes)
            return fail(QObject::tr("The package contains an oversized entry and was rejected."));
    }

    auto extract = [&](const char* name, QByteArray* out) {
        const int idx = mz_zip_reader_locate_file(&zip, name, nullptr, 0);
        if (idx < 0) return false;
        size_t sz = 0;
        void* p = mz_zip_reader_extract_to_heap(&zip, mz_uint(idx), &sz, 0);
        if (!p) return false; // includes CRC failures
        *out = QByteArray(static_cast<const char*>(p), qsizetype(sz));
        mz_free(p);
        return true;
    };

    QByteArray manBytes, docBytes;
    if (!extract("manifest.json", &manBytes) || !extract("document.json", &docBytes))
        return fail(QObject::tr("The package is incomplete or corrupted."));

    QJsonParseError pe;
    const QJsonObject man = QJsonDocument::fromJson(manBytes, &pe).object();
    if (pe.error != QJsonParseError::NoError || man.value("format").toString() != "txpub")
        return fail(QObject::tr("The package manifest is invalid."));
    const int ver = man.value("formatVersion").toInt(0);
    if (ver < 1) return fail(QObject::tr("The package has an invalid format version."));
    if (ver > kFormatVersion)
        return fail(QObject::tr("This file was created by a newer version of TRIONEX Publisher."));
    // (Older versions would be migrated here. Version 1 is the first format.)

    const QString expected = man.value("documentSha256").toString();
    const QString actual =
        QString::fromLatin1(QCryptographicHash::hash(docBytes, QCryptographicHash::Sha256).toHex());
    if (expected != actual)
        return fail(QObject::tr("The document data does not match its checksum; the file is corrupted."));

    const QJsonDocument jd = QJsonDocument::fromJson(docBytes, &pe);
    if (pe.error != QJsonParseError::NoError || !jd.isObject())
        return fail(QObject::tr("The document data could not be read."));
    return Document::fromJson(jd.object(), error);
}

bool savePackage(const Document& doc, const QString& path, QString* error) {
    const QStringList problems = doc.validate();
    if (!problems.isEmpty()) {
        if (error) *error = problems.first();
        return false;
    }
    const QByteArray bytes = buildPackageBytes(doc, error);
    if (bytes.isEmpty()) return false;
    QSaveFile f(path); // writes to a temp file; commit() atomically replaces the target
    if (!f.open(QIODevice::WriteOnly)) {
        if (error) *error = f.errorString();
        return false;
    }
    if (f.write(bytes) != bytes.size() || !f.commit()) {
        if (error) *error = f.errorString();
        return false;
    }
    return true;
}

std::unique_ptr<Document> loadPackage(const QString& path, QString* error) {
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly)) {
        if (error) *error = f.errorString();
        return nullptr;
    }
    return loadPackageFromBytes(f.readAll(), error);
}

} // namespace trionex
