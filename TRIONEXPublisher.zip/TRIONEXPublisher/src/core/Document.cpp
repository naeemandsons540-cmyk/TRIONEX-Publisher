#include "Document.h"

#include <QJsonArray>
#include <QSet>
#include <QUuid>
#include <cmath>

namespace trionex {

double unitToPoints(double v, Unit u) {
    switch (u) {
    case Unit::Millimetre: return v * 72.0 / 25.4;
    case Unit::Centimetre: return v * 72.0 / 2.54;
    case Unit::Inch: return v * 72.0;
    case Unit::Point: return v;
    }
    return v;
}

double pointsToUnit(double p, Unit u) {
    switch (u) {
    case Unit::Millimetre: return p * 25.4 / 72.0;
    case Unit::Centimetre: return p * 2.54 / 72.0;
    case Unit::Inch: return p / 72.0;
    case Unit::Point: return p;
    }
    return p;
}

QString unitName(Unit u) {
    switch (u) {
    case Unit::Millimetre: return QStringLiteral("mm");
    case Unit::Centimetre: return QStringLiteral("cm");
    case Unit::Inch: return QStringLiteral("in");
    case Unit::Point: return QStringLiteral("pt");
    }
    return QStringLiteral("pt");
}

std::optional<Unit> unitFromName(const QString& n) {
    if (n == QLatin1String("mm")) return Unit::Millimetre;
    if (n == QLatin1String("cm")) return Unit::Centimetre;
    if (n == QLatin1String("in")) return Unit::Inch;
    if (n == QLatin1String("pt")) return Unit::Point;
    return std::nullopt;
}

QString objectTypeName(ObjectType t) {
    switch (t) {
    case ObjectType::Rectangle: return QStringLiteral("rectangle");
    case ObjectType::Ellipse: return QStringLiteral("ellipse");
    case ObjectType::Line: return QStringLiteral("line");
    }
    return QStringLiteral("rectangle");
}

std::optional<ObjectType> objectTypeFromName(const QString& n) {
    if (n == QLatin1String("rectangle")) return ObjectType::Rectangle;
    if (n == QLatin1String("ellipse")) return ObjectType::Ellipse;
    if (n == QLatin1String("line")) return ObjectType::Line;
    return std::nullopt;
}

// ---------------------------------------------------------------- Object

QJsonObject Object::toJson() const {
    QJsonObject o;
    o["id"] = id;
    o["type"] = objectTypeName(type);
    o["layer"] = layerId;
    o["x"] = x;
    o["y"] = y;
    o["w"] = w;
    o["h"] = h;
    o["fill"] = fill.name(QColor::HexArgb);
    o["stroke"] = stroke.name(QColor::HexArgb);
    o["strokeWidth"] = strokeWidth;
    o["locked"] = locked;
    return o;
}

std::optional<Object> Object::fromJson(const QJsonObject& j, QString* error) {
    auto fail = [&](const QString& m) -> std::optional<Object> {
        if (error) *error = m;
        return std::nullopt;
    };
    Object o;
    o.id = j.value("id").toString();
    if (o.id.isEmpty()) return fail(QObject::tr("An object has no id."));
    const auto t = objectTypeFromName(j.value("type").toString());
    if (!t) return fail(QObject::tr("Object %1 has an unknown type.").arg(o.id));
    o.type = *t;
    o.layerId = j.value("layer").toString();

    double* fields[] = {&o.x, &o.y, &o.w, &o.h, &o.strokeWidth};
    const char* keys[] = {"x", "y", "w", "h", "strokeWidth"};
    for (int i = 0; i < 5; ++i) {
        const QJsonValue v = j.value(QString::fromLatin1(keys[i]));
        if (!v.isDouble() || !std::isfinite(v.toDouble()))
            return fail(QObject::tr("Object %1 has an invalid '%2' value.")
                            .arg(o.id, QString::fromLatin1(keys[i])));
        *fields[i] = v.toDouble();
    }
    if (o.strokeWidth < 0 || o.strokeWidth > 1000)
        return fail(QObject::tr("Object %1 has an invalid stroke width.").arg(o.id));

    const QColor f(j.value("fill").toString());
    const QColor s(j.value("stroke").toString());
    if (!f.isValid() || !s.isValid())
        return fail(QObject::tr("Object %1 has an invalid colour.").arg(o.id));
    o.fill = f;
    o.stroke = s;
    o.locked = j.value("locked").toBool(false);
    return o;
}

// -------------------------------------------------------------- Document

Document::Document(QObject* parent) : QObject(parent) {
    Layer l;
    l.id = QStringLiteral("layer-1");
    l.name = QStringLiteral("Layer 1");
    m_layers.append(l);
}

QString Document::newId() { return QUuid::createUuid().toString(QUuid::WithoutBraces); }

QString Document::validateSetup(const PageSetup& s) {
    auto bad = [](double v) { return !std::isfinite(v); };
    if (bad(s.width) || bad(s.height) || s.width < 10 || s.height < 10 || s.width > 14400 ||
        s.height > 14400)
        return QObject::tr("Page width and height must be between 10 pt and 14400 pt (200 in).");
    for (double m : {s.marginTop, s.marginBottom, s.marginLeft, s.marginRight})
        if (bad(m) || m < 0) return QObject::tr("Margins cannot be negative.");
    if (s.marginLeft + s.marginRight >= s.width || s.marginTop + s.marginBottom >= s.height)
        return QObject::tr("The margins leave no room for content.");
    if (bad(s.bleed) || s.bleed < 0 || s.bleed > 72)
        return QObject::tr("Bleed must be between 0 and 72 pt.");
    if (s.columns < 1 || s.columns > 12) return QObject::tr("Columns must be between 1 and 12.");
    if (bad(s.gutter) || s.gutter < 0) return QObject::tr("The column gutter cannot be negative.");
    const double content = s.width - s.marginLeft - s.marginRight;
    if (s.columns > 1 && s.gutter * (s.columns - 1) >= content)
        return QObject::tr("The column gutters are wider than the text area.");
    return {};
}

void Document::setSetup(const PageSetup& s) {
    m_setup = s;
    emit changed();
}

void Document::insertPage(int index, const Page& p) {
    if (index < 0 || index > m_pages.size()) index = int(m_pages.size());
    m_pages.insert(index, p);
    emit changed();
}

Page Document::removePage(int index) {
    Page p = m_pages.at(index);
    m_pages.removeAt(index);
    emit changed();
    return p;
}

const Layer* Document::layer(const QString& id) const {
    for (const Layer& l : m_layers)
        if (l.id == id) return &l;
    return nullptr;
}

void Document::setLayer(const Layer& nl) {
    for (Layer& l : m_layers)
        if (l.id == nl.id) {
            l = nl;
            emit changed();
            return;
        }
}

void Document::insertObject(int pageIndex, int index, const Object& o) {
    if (pageIndex < 0 || pageIndex >= m_pages.size()) return;
    auto& objs = m_pages[pageIndex].objects;
    if (index < 0 || index > objs.size()) index = int(objs.size());
    objs.insert(index, o);
    emit changed();
}

bool Document::removeObject(const QString& id, int* pageIndex, int* index, Object* removed) {
    for (int p = 0; p < m_pages.size(); ++p) {
        auto& objs = m_pages[p].objects;
        for (int i = 0; i < objs.size(); ++i) {
            if (objs[i].id != id) continue;
            if (pageIndex) *pageIndex = p;
            if (index) *index = i;
            if (removed) *removed = objs[i];
            objs.removeAt(i);
            emit changed();
            return true;
        }
    }
    return false;
}

bool Document::replaceObject(const QString& id, const Object& o) {
    int p, i;
    if (!findObject(id, &p, &i)) return false;
    m_pages[p].objects[i] = o;
    emit changed();
    return true;
}

bool Document::moveObject(const QString& id, int newIndex) {
    int p, i;
    if (!findObject(id, &p, &i)) return false;
    auto& objs = m_pages[p].objects;
    newIndex = qBound(0, newIndex, int(objs.size()) - 1);
    if (newIndex == i) return true;
    objs.move(i, newIndex);
    emit changed();
    return true;
}

bool Document::findObject(const QString& id, int* pageIndex, int* index) const {
    for (int p = 0; p < m_pages.size(); ++p)
        for (int i = 0; i < m_pages[p].objects.size(); ++i)
            if (m_pages[p].objects[i].id == id) {
                if (pageIndex) *pageIndex = p;
                if (index) *index = i;
                return true;
            }
    return false;
}

const Object* Document::object(const QString& id) const {
    int p, i;
    return findObject(id, &p, &i) ? &m_pages[p].objects[i] : nullptr;
}

bool Document::isLayerVisible(const QString& layerId) const {
    const Layer* l = layer(layerId);
    return l && l->visible;
}

bool Document::canEdit(const QString& id) const {
    const Object* o = object(id);
    if (!o || o->locked) return false;
    const Layer* l = layer(o->layerId);
    return l && l->visible && !l->locked;
}

QStringList Document::validate() const {
    QStringList problems;
    const QString setupErr = validateSetup(m_setup);
    if (!setupErr.isEmpty()) problems << setupErr;
    if (m_pages.isEmpty()) problems << tr("The document has no pages.");
    if (m_pages.size() > 10000) problems << tr("The document has too many pages.");
    QSet<QString> ids;
    for (const Page& p : m_pages) {
        if (p.id.isEmpty() || ids.contains(p.id)) problems << tr("Duplicate or empty page id.");
        ids.insert(p.id);
        for (const Object& o : p.objects) {
            if (ids.contains(o.id)) problems << tr("Duplicate object id %1.").arg(o.id);
            ids.insert(o.id);
            if (!layer(o.layerId))
                problems << tr("Object %1 refers to a missing layer.").arg(o.id);
        }
    }
    return problems;
}

QJsonObject Document::toJson() const {
    QJsonObject j;
    j["name"] = m_name;
    QJsonObject s;
    s["width"] = m_setup.width;
    s["height"] = m_setup.height;
    s["unit"] = unitName(m_setup.displayUnit);
    s["marginTop"] = m_setup.marginTop;
    s["marginBottom"] = m_setup.marginBottom;
    s["marginLeft"] = m_setup.marginLeft;
    s["marginRight"] = m_setup.marginRight;
    s["bleed"] = m_setup.bleed;
    s["columns"] = m_setup.columns;
    s["gutter"] = m_setup.gutter;
    s["facingPages"] = m_setup.facingPages;
    j["setup"] = s;

    QJsonArray layers;
    for (const Layer& l : m_layers) {
        QJsonObject lo;
        lo["id"] = l.id;
        lo["name"] = l.name;
        lo["visible"] = l.visible;
        lo["locked"] = l.locked;
        layers.append(lo);
    }
    j["layers"] = layers;

    QJsonArray pages;
    for (const Page& p : m_pages) {
        QJsonObject po;
        po["id"] = p.id;
        QJsonArray objs;
        for (const Object& o : p.objects) objs.append(o.toJson());
        po["objects"] = objs;
        pages.append(po);
    }
    j["pages"] = pages;
    return j;
}

std::unique_ptr<Document> Document::fromJson(const QJsonObject& j, QString* error) {
    auto fail = [&](const QString& m) {
        if (error) *error = m;
        return std::unique_ptr<Document>();
    };
    auto doc = std::make_unique<Document>();
    doc->m_name = j.value("name").toString(QStringLiteral("Untitled"));

    const QJsonObject s = j.value("setup").toObject();
    PageSetup ps;
    struct F {
        const char* k;
        double* d;
    };
    for (F f : {F{"width", &ps.width}, F{"height", &ps.height}, F{"marginTop", &ps.marginTop},
                F{"marginBottom", &ps.marginBottom}, F{"marginLeft", &ps.marginLeft},
                F{"marginRight", &ps.marginRight}, F{"bleed", &ps.bleed},
                F{"gutter", &ps.gutter}}) {
        const QJsonValue v = s.value(QString::fromLatin1(f.k));
        if (!v.isDouble())
            return fail(tr("The page setup is missing '%1'.").arg(QString::fromLatin1(f.k)));
        *f.d = v.toDouble();
    }
    ps.columns = s.value("columns").toInt(1);
    ps.facingPages = s.value("facingPages").toBool(false);
    const auto u = unitFromName(s.value("unit").toString());
    if (!u) return fail(tr("The page setup has an unknown unit."));
    ps.displayUnit = *u;
    const QString setupErr = validateSetup(ps);
    if (!setupErr.isEmpty()) return fail(setupErr);
    doc->m_setup = ps;

    doc->m_layers.clear();
    QSet<QString> layerIds;
    for (const QJsonValue& v : j.value("layers").toArray()) {
        const QJsonObject lo = v.toObject();
        Layer l;
        l.id = lo.value("id").toString();
        l.name = lo.value("name").toString();
        l.visible = lo.value("visible").toBool(true);
        l.locked = lo.value("locked").toBool(false);
        if (l.id.isEmpty() || layerIds.contains(l.id)) return fail(tr("Invalid layer table."));
        layerIds.insert(l.id);
        doc->m_layers.append(l);
    }
    if (doc->m_layers.isEmpty()) return fail(tr("The document has no layers."));

    const QJsonArray pages = j.value("pages").toArray();
    if (pages.isEmpty()) return fail(tr("The document has no pages."));
    for (const QJsonValue& pv : pages) {
        const QJsonObject po = pv.toObject();
        Page p;
        p.id = po.value("id").toString();
        for (const QJsonValue& ov : po.value("objects").toArray()) {
            QString oe;
            const auto o = Object::fromJson(ov.toObject(), &oe);
            if (!o) return fail(oe);
            p.objects.append(*o);
        }
        doc->m_pages.append(p);
    }
    const QStringList problems = doc->validate();
    if (!problems.isEmpty()) return fail(problems.first());
    return doc;
}

} // namespace trionex
