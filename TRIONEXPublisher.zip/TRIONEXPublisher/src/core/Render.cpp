#include "Render.h"

#include <QFile>
#include <QMarginsF>
#include <QPageLayout>
#include <QPageSize>
#include <QPdfWriter>

namespace trionex {

void paintObject(QPainter* p, const Object& o) {
    p->save();
    if (o.strokeWidth > 0)
        p->setPen(QPen(o.stroke, o.strokeWidth, Qt::SolidLine, Qt::FlatCap, Qt::MiterJoin));
    else
        p->setPen(Qt::NoPen);
    switch (o.type) {
    case ObjectType::Rectangle:
        p->setBrush(o.fill);
        p->drawRect(QRectF(0, 0, o.w, o.h));
        break;
    case ObjectType::Ellipse:
        p->setBrush(o.fill);
        p->drawEllipse(QRectF(0, 0, o.w, o.h));
        break;
    case ObjectType::Line:
        p->setBrush(Qt::NoBrush);
        p->drawLine(QPointF(0, 0), QPointF(o.w, o.h));
        break;
    }
    p->restore();
}

void paintPage(QPainter* p, const Document& doc, int pageIndex) {
    for (const Object& o : doc.page(pageIndex).objects) {
        if (!doc.isLayerVisible(o.layerId)) continue;
        p->save();
        p->translate(o.x, o.y);
        paintObject(p, o);
        p->restore();
    }
}

bool exportPdf(const Document& doc, const QString& path, QString* error) {
    if (doc.pageCount() < 1) {
        if (error) *error = QObject::tr("The document has no pages.");
        return false;
    }
    {
        QPdfWriter w(path);
        w.setResolution(72); // 1 painter unit == 1 point
        w.setTitle(doc.name());
        w.setCreator(QStringLiteral("TRIONEX Publisher"));
        const PageSetup& s = doc.setup();
        w.setPageSize(QPageSize(QSizeF(s.width, s.height), QPageSize::Point, QString(),
                                QPageSize::ExactMatch));
        w.setPageMargins(QMarginsF(0, 0, 0, 0), QPageLayout::Point);
        QPainter p;
        if (!p.begin(&w)) {
            if (error) *error = QObject::tr("Could not write to %1.").arg(path);
            return false;
        }
        p.setRenderHint(QPainter::Antialiasing);
        for (int i = 0; i < doc.pageCount(); ++i) {
            if (i > 0) w.newPage();
            paintPage(&p, doc, i);
        }
        p.end();
    }
    if (!QFile::exists(path) || QFile(path).size() == 0) {
        if (error) *error = QObject::tr("The PDF file was not created.");
        return false;
    }
    return true;
}

} // namespace trionex
