#pragma once
#include <QByteArray>
#include <QString>
#include <memory>
#include "Document.h"

namespace trionex {

// Returns true if a ZIP entry name is permitted in a .txpub package
// (no traversal, no absolute paths, known top-level names only).
bool isSafeEntryName(const QString& name);

QByteArray buildPackageBytes(const Document& doc, QString* error);
std::unique_ptr<Document> loadPackageFromBytes(const QByteArray& bytes, QString* error);

// Atomic: written to a temporary file and renamed over the target on success.
bool savePackage(const Document& doc, const QString& path, QString* error);
std::unique_ptr<Document> loadPackage(const QString& path, QString* error);

} // namespace trionex
