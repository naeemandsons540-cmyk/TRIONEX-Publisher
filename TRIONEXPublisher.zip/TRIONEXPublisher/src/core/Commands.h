#pragma once
#include <QUndoCommand>
#include <QVector>
#include "Document.h"

namespace trionex {

class AddObjectCommand : public QUndoCommand {
public:
    AddObjectCommand(Document* d, int pageIndex, const Object& o);
    void undo() override;
    void redo() override;

private:
    Document* m_doc;
    int m_page;
    Object m_obj;
};

class DeleteObjectsCommand : public QUndoCommand {
public:
    DeleteObjectsCommand(Document* d, const QStringList& ids);
    void undo() override;
    void redo() override;

private:
    struct Rec {
        int page = 0, index = 0;
        Object obj;
    };
    Document* m_doc;
    QStringList m_ids;
    QVector<Rec> m_removed;
};

class ModifyObjectCommand : public QUndoCommand {
public:
    ModifyObjectCommand(Document* d, const Object& before, const Object& after,
                        const QString& text);
    void undo() override;
    void redo() override;

private:
    Document* m_doc;
    Object m_before, m_after;
};

class ArrangeCommand : public QUndoCommand {
public:
    ArrangeCommand(Document* d, const QString& id, bool toFront);
    void undo() override;
    void redo() override;

private:
    Document* m_doc;
    QString m_id;
    bool m_front;
    int m_oldIndex = -1;
};

class AddPageCommand : public QUndoCommand {
public:
    AddPageCommand(Document* d, int index, const Page& p);
    void undo() override;
    void redo() override;

private:
    Document* m_doc;
    int m_index;
    Page m_page;
};

class DeletePageCommand : public QUndoCommand {
public:
    DeletePageCommand(Document* d, int index);
    void undo() override;
    void redo() override;

private:
    Document* m_doc;
    int m_index;
    Page m_page;
};

} // namespace trionex
