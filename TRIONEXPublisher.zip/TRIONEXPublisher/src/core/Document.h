#pragma once
#include <QColor>
#include <QJsonObject>
#include <QObject>
#include <QString>
#include <QStringList>
#include <QVector>
#include <memory>
#include <optional>

namespace trionex {

inline constexpr int kFormatVersion = 1;
inline constexpr const char* kAppVersion = "0.1.0";

enum class Unit { Millimetre, Centimetre, Inch, Point };
double unitToPoints(double value, Unit unit);
double pointsToUnit(double points, Unit unit);
QString unitName(Unit unit);
std::optional<Unit> unitFromName(const QString& name);

enum class ObjectType { Rectangle, Ellipse, Line };
QString objectTypeName(ObjectType t);
std::optional<ObjectType> objectTypeFromName(const QString& name);

// All geometry is stored in points (1/72 inch). For lines, (x,y) is the start
// point and (w,h) is the vector to the end point (may be negative).
struct Object {
    QString id;
    ObjectType type = ObjectType::Rectangle;
    QString layerId;
    double x = 0, y = 0, w = 100, h = 100;
    QColor fill = QColor(220, 220, 220);
    QColor stroke = QColor(0, 0, 0);
    double strokeWidth = 1.0;
    bool locked = false;

    QJsonObject toJson() const;
    static std::optional<Object> fromJson(const QJsonObject& j, QString* error);
};

struct Layer {
    QString id;
    QString name;
    bool visible = true;
    bool locked = false;
};

struct Page {
    QString id;
    QVector<Object> objects; // index = z-order, last is on top
};

struct PageSetup {
    double width = 595.2756, height = 841.8898; // A4 in points
    Unit displayUnit = Unit::Millimetre;
    double marginTop = 36, marginBottom = 36, marginLeft = 36, marginRight = 36;
    double bleed = 0;
    int columns = 1;
    double gutter = 12;
    bool facingPages = false;
};

class Document : public QObject {
    Q_OBJECT
public:
    explicit Document(QObject* parent = nullptr);

    static QString newId();
    // Returns an empty string if valid, otherwise a user-readable error.
    static QString validateSetup(const PageSetup& s);

    const QString& name() const { return m_name; }
    void setName(const QString& n) { m_name = n; }
    const PageSetup& setup() const { return m_setup; }
    void setSetup(const PageSetup& s);

    int pageCount() const { return int(m_pages.size()); }
    const Page& page(int i) const { return m_pages.at(i); }
    void insertPage(int index, const Page& p);
    Page removePage(int index);

    const QVector<Layer>& layers() const { return m_layers; }
    QString defaultLayerId() const { return m_layers.first().id; }
    const Layer* layer(const QString& id) const;
    void setLayer(const Layer& l);

    void insertObject(int pageIndex, int index, const Object& o); // index<0 => top
    bool removeObject(const QString& id, int* pageIndex = nullptr, int* index = nullptr,
                      Object* removed = nullptr);
    bool replaceObject(const QString& id, const Object& o);
    bool moveObject(const QString& id, int newIndex);
    bool findObject(const QString& id, int* pageIndex, int* index) const;
    const Object* object(const QString& id) const;
    // Enforced by the engine: false if the object or its layer is locked, or the layer is hidden.
    bool canEdit(const QString& id) const;
    bool isLayerVisible(const QString& layerId) const;

    QStringList validate() const;
    QJsonObject toJson() const;
    static std::unique_ptr<Document> fromJson(const QJsonObject& j, QString* error);

signals:
    void changed();

private:
    QString m_name = QStringLiteral("Untitled");
    PageSetup m_setup;
    QVector<Layer> m_layers;
    QVector<Page> m_pages;
};

} // namespace trionex
