#pragma once
#include <QPainter>
#include <QString>
#include "Document.h"

namespace trionex {

// Paints an object in its local coordinate system (origin at the object's x,y).
void paintObject(QPainter* p, const Object& o);

// Paints all visible objects of a page, in z-order, in page coordinates (points).
void paintPage(QPainter* p, const Document& doc, int pageIndex);

// Writes every page to a PDF (vector output). Returns false and sets error on failure.
bool exportPdf(const Document& doc, const QString& path, QString* error);

} // namespace trionex
