#include "Commands.h"

namespace trionex {

AddObjectCommand::AddObjectCommand(Document* d, int pageIndex, const Object& o)
    : m_doc(d), m_page(pageIndex), m_obj(o) {
    setText(QObject::tr("Add %1").arg(objectTypeName(o.type)));
}
void AddObjectCommand::redo() { m_doc->insertObject(m_page, -1, m_obj); }
void AddObjectCommand::undo() { m_doc->removeObject(m_obj.id); }

DeleteObjectsCommand::DeleteObjectsCommand(Document* d, const QStringList& ids)
    : m_doc(d), m_ids(ids) {
    setText(QObject::tr("Delete"));
}
void DeleteObjectsCommand::redo() {
    m_removed.clear();
    for (const QString& id : m_ids) {
        Rec r;
        if (m_doc->removeObject(id, &r.page, &r.index, &r.obj)) m_removed.append(r);
    }
}
void DeleteObjectsCommand::undo() {
    for (int i = int(m_removed.size()) - 1; i >= 0; --i)
        m_doc->insertObject(m_removed[i].page, m_removed[i].index, m_removed[i].obj);
}

ModifyObjectCommand::ModifyObjectCommand(Document* d, const Object& before, const Object& after,
                                         const QString& text)
    : m_doc(d), m_before(before), m_after(after) {
    setText(text);
}
void ModifyObjectCommand::redo() { m_doc->replaceObject(m_after.id, m_after); }
void ModifyObjectCommand::undo() { m_doc->replaceObject(m_before.id, m_before); }

ArrangeCommand::ArrangeCommand(Document* d, const QString& id, bool toFront)
    : m_doc(d), m_id(id), m_front(toFront) {
    setText(toFront ? QObject::tr("Bring to Front") : QObject::tr("Send to Back"));
}
void ArrangeCommand::redo() {
    int p = 0, i = 0;
    if (!m_doc->findObject(m_id, &p, &i)) return;
    m_oldIndex = i;
    m_doc->moveObject(m_id, m_front ? int(m_doc->page(p).objects.size()) - 1 : 0);
}
void ArrangeCommand::undo() {
    if (m_oldIndex >= 0) m_doc->moveObject(m_id, m_oldIndex);
}

AddPageCommand::AddPageCommand(Document* d, int index, const Page& p)
    : m_doc(d), m_index(index), m_page(p) {
    setText(QObject::tr("Add Page"));
}
void AddPageCommand::redo() { m_doc->insertPage(m_index, m_page); }
void AddPageCommand::undo() { m_doc->removePage(m_index); }

DeletePageCommand::DeletePageCommand(Document* d, int index) : m_doc(d), m_index(index) {
    setText(QObject::tr("Delete Page"));
}
void DeletePageCommand::redo() { m_page = m_doc->removePage(m_index); }
void DeletePageCommand::undo() { m_doc->insertPage(m_index, m_page); }

} // namespace trionex
